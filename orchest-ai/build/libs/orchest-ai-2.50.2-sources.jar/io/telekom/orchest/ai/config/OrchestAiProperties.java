package io.telekom.orchest.ai.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ConfigurationProperties(prefix = "orchest.ai")
public class OrchestAiProperties {

    private boolean enabled;
    private String endPoint;
    private String apiKey;
    private String deploymentName;
    private String apiVersion;
    private String model;
    private Map<String, McpServerProperties> mcpServers;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class McpServerProperties {
        private String url;
        private boolean enabled;
        private Map<String, String> headers;
    }

}
