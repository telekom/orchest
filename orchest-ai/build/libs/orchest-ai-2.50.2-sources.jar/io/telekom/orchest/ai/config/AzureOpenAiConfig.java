package io.telekom.orchest.ai.config;

import com.openai.azure.AzureOpenAIServiceVersion;
import com.openai.client.OpenAIClient;
import com.openai.client.okhttp.OpenAIOkHttpClient;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@EnableConfigurationProperties(OrchestAiProperties.class)
@Configuration
@ConditionalOnProperty(prefix = "orchest.ai", name = "enabled", havingValue = "true", matchIfMissing = false)
public class AzureOpenAiConfig {

    @Bean
    public OpenAIClient openAIClient(OrchestAiProperties properties) {
        return OpenAIOkHttpClient.builder()
                .baseUrl(properties.getEndPoint())
                .apiKey(properties.getApiKey())
                .azureServiceVersion(AzureOpenAIServiceVersion.fromString(properties.getApiVersion()))
                .build();
    }

    @Bean
    public OpenAiChatModel openAiChatModel(OpenAIClient openAIClient, OrchestAiProperties properties) {
        OpenAiChatOptions options = OpenAiChatOptions.builder()
                .model(properties.getModel())
                .apiKey(properties.getApiKey())
                .baseUrl(properties.getEndPoint())
                .deploymentName(properties.getDeploymentName())
                .temperature(0.7)
                .build();

        return OpenAiChatModel.builder()
                .openAiClient(openAIClient)
                .options(options)
                .build();
    }

    @Bean
    public ChatClient chatClient(OpenAiChatModel openAiChatModel) {
        return ChatClient.builder(openAiChatModel).build();
    }
}