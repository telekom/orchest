package io.telekom.orchest.ai.service;

import io.telekom.orchest.ai.model.ChatRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ToolContext;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import org.springframework.ai.tool.metadata.ToolMetadata;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static io.telekom.orchest.ai.prompts.ProcessInstancePrompts.*;

@RequiredArgsConstructor
public class ChatService {

    private final boolean enabled;
    private final ChatClient chatClient;
    private final List<ToolCallback> toolCallbacks;

    public String askAI(String prompt) {
        if (!enabled) {
            return null;
        }
        UserMessage userMessage = new UserMessage(prompt);
        return chatClient.prompt(Prompt.builder().messages(PROCESS_INSTANCE_DETAILED_ANALYSIS_SYSTEM_PROMPT, userMessage).build())
                .tools(t -> t.callbacks(toolCallbacks))
                .call().content();
    }

    public static final String TOOL_COUNT_PREFIX = "__TOOL_COUNT:";

    public Flux<String> askAIStream(ChatRequest chatRequest) {
        if (!enabled) {
            return null;
        }

        UserMessage userMessage = new UserMessage(chatRequest.getUserMessage());
        SystemMessage systemMessage = switch (chatRequest.getChatType()) {
            case INCIDENT_ANALYSIS -> PROCESS_INSTANCE_INCIDENT_ANALYSIS_SYSTEM_PROMPT;
            case SUGGEST_FIX -> PROCESS_INSTANCE_SUGGEST_FIX_SYSTEM_PROMPT;
            default -> PROCESS_INSTANCE_PATTERN_ANALYSIS_SYSTEM_PROMPT;
        };

        AtomicInteger toolCallCount = new AtomicInteger(0);
        Flux<String> content = chatClient.prompt(Prompt.builder().messages(systemMessage, userMessage).build())
                .tools(t -> t.callbacks(toolCallbacks))
                .stream()
                .content();

        return content.concatWith(Mono.fromCallable(() -> TOOL_COUNT_PREFIX + toolCallCount.get()));
    }
}
