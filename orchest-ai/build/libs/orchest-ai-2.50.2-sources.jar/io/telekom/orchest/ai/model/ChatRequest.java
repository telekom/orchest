package io.telekom.orchest.ai.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChatRequest {
    private String userMessage;
    @Builder.Default
    private ChatType chatType = ChatType.DEFAULT_ANALYSIS;

    public enum ChatType{ DETAILED_ANALYSIS, INCIDENT_ANALYSIS, SUGGEST_FIX, DEFAULT_ANALYSIS }
}
