package io.telekom.orchest.alerting.config;

import io.telekom.orchest.alerting.service.AlertLifecycleService;
import io.telekom.orchest.api.core.adapters.data.repository.AlertRepository;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;

/**
 * Spring wiring for the persistent alert lifecycle (raise SPI, scheduler).
 * REST controller is component-scanned separately and gated with web conditions.
 */
@Configuration
public class AlertAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean(Clock.class)
    public Clock alertClock() {
        return Clock.systemUTC();
    }

    @Bean
    @ConditionalOnBean(AlertRepository.class)
    @ConditionalOnMissingBean(AlertLifecycleService.class)
    public AlertLifecycleService alertLifecycleService(AlertRepository alertRepository, Clock clock) {
        return new AlertLifecycleService(alertRepository, clock);
    }
}
