package io.telekom.orchest.alerting.service;

import io.telekom.orchest.api.core.adapters.data.model.AlertingMailerConfig;
import io.telekom.orchest.api.core.adapters.data.model.AlertRecipients;
import io.telekom.orchest.api.core.adapters.data.repository.AlertingMailerConfigRepository;
import io.telekom.orchest.api.core.adapters.data.repository.AlertingMailerConfigRepository.MailerConfigPage;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AlertingMailerConfigService {

    private final AlertingMailerConfigRepository repository;

    public List<AlertingMailerConfig> findAll() {
        return repository.findAll();
    }

    public MailerConfigPage findAll(int page, int size) {
        return repository.findAll(page, size);
    }

    public Optional<AlertingMailerConfig> findByProcessId(String id) {
        return repository.findByProcessId(id);
    }

    public AlertingMailerConfig create(String processId, AlertRecipients alertingRecipient) {
        return repository.save(AlertingMailerConfig.builder()
                .processId(processId)
                .alertingRecipient(alertingRecipient)
                .build());
    }

    public Optional<AlertingMailerConfig> update(String id, String processId, AlertRecipients alertingRecipient) {
        return repository.findById(id).map(existing -> {
            existing.setProcessId(processId);
            existing.setAlertingRecipient(alertingRecipient);
            return repository.save(existing);
        });
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }
}
