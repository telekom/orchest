package io.telekom.orchest.alerting.service;

import io.telekom.orchest.alerting.api.RaiseAlertRequest;
import io.telekom.orchest.alerting.api.exception.AlertNotFoundException;
import io.telekom.orchest.alerting.api.exception.AlertTransitionException;
import io.telekom.orchest.api.core.adapters.data.model.Alert;
import io.telekom.orchest.api.core.adapters.data.model.AlertRecipients;
import io.telekom.orchest.api.core.adapters.data.model.AlertState;
import io.telekom.orchest.api.core.adapters.data.repository.AlertRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.util.StringUtils;

import io.telekom.orchest.api.core.adapters.data.repository.AlertRepository.AlertPage;
import io.telekom.orchest.api.core.adapters.data.repository.AlertRepository.AlertStats;

import java.time.Clock;
import java.time.Instant;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

/**
 * Owns raise (SPI) and lifecycle transitions (REST). Does not send notifications —
 * that is the scheduler's job while state is {@link AlertState#FIRING}.
 */
@RequiredArgsConstructor
public class AlertLifecycleService {

    private final AlertRepository alertRepository;
    private final Clock clock;

    public Alert raise(RaiseAlertRequest request) {
        Objects.requireNonNull(request, "request");
        if (!StringUtils.hasText(request.getSource()) || !StringUtils.hasText(request.getAlertKey())) {
            throw new IllegalArgumentException("source and alertKey are required");
        }
        if (!StringUtils.hasText(request.getSubject()) || !StringUtils.hasText(request.getBody())) {
            throw new IllegalArgumentException("subject and body are required");
        }

        Instant now = clock.instant();
        String fingerprint = Alert.fingerprintOf(request.getSource(), request.getAlertKey());

        Alert alert = alertRepository.findByFingerprint(fingerprint)
                .map(existing -> applyRaise(existing, request, now))
                .orElseGet(() -> newAlert(request, fingerprint, now));

        return alertRepository.save(alert);
    }

    public Alert getRequired(String id) {
        return alertRepository.findById(id).orElseThrow(() -> new AlertNotFoundException(id));
    }

    public AlertPage list(AlertState state, String processDefinitionId, Instant createdFrom, Instant createdTo, int page, int size, String sort) {
        return alertRepository.findAll(state, processDefinitionId, createdFrom, createdTo, page, size, sort);
    }

    public AlertPage listByStates(Collection<AlertState> states, int page, int size) {
        return alertRepository.findByStates(states, page, size);
    }

    public List<AlertStats> firingStats() {
        return alertRepository.firingStats();
    }

    public Alert acknowledge(String id, String actor) {
        Alert alert = getRequired(id);
        requireNotResolved(alert, "acknowledge");
        if (alert.getState() == AlertState.ACKNOWLEDGED) {
            return alert;
        }
        Instant now = clock.instant();
        alert.setState(AlertState.ACKNOWLEDGED);
        alert.setAcknowledgedAt(now);
        alert.setAcknowledgedBy(actor);
        alert.setUpdatedAt(now);
        return alertRepository.save(alert);
    }

    public Alert silence(String id, String actor) {
        Alert alert = getRequired(id);
        requireNotResolved(alert, "silence");
        if (alert.getState() == AlertState.SILENCED) {
            return alert;
        }
        Instant now = clock.instant();
        alert.setState(AlertState.SILENCED);
        alert.setSilencedAt(now);
        alert.setSilencedBy(actor);
        alert.setUpdatedAt(now);
        return alertRepository.save(alert);
    }

    public Alert unmute(String id) {
        Alert alert = getRequired(id);
        if (alert.getState() != AlertState.SILENCED) {
            throw new AlertTransitionException(
                    "Cannot unmute alert in state " + alert.getState() + "; expected SILENCED");
        }
        Instant now = clock.instant();
        alert.setState(AlertState.FIRING);
        alert.setSilencedAt(null);
        alert.setSilencedBy(null);
        alert.setUpdatedAt(now);
        return alertRepository.save(alert);
    }

    public Alert resolve(String id) {
        Alert alert = getRequired(id);
        if (alert.getState() == AlertState.RESOLVED) {
            throw new AlertTransitionException("Alert is already RESOLVED");
        }
        Instant now = clock.instant();
        alert.setState(AlertState.RESOLVED);
        alert.setResolvedAt(now);
        alert.setUpdatedAt(now);
        return alertRepository.save(alert);
    }

    public Alert markTriggered(Alert alert) {
        Instant now = clock.instant();
        alert.setLastTriggeredAt(now);
        alert.setUpdatedAt(now);
        return alertRepository.save(alert);
    }

    private static void requireNotResolved(Alert alert, String action) {
        if (alert.getState() == AlertState.RESOLVED) {
            throw new AlertTransitionException("Cannot " + action + " a RESOLVED alert");
        }
    }

    private static Alert newAlert(RaiseAlertRequest request, String fingerprint, Instant now) {
        return Alert.builder()
                .source(request.getSource())
                .alertKey(request.getAlertKey())
                .fingerprint(fingerprint)
                .state(AlertState.FIRING)
                .count(1)
                .severity(request.getSeverity())
                .metadata(copyMetadata(request))
                .subject(request.getSubject())
                .body(request.getBody())
                .recipients(request.getRecipients() != null ? request.getRecipients() : new AlertRecipients())
                .resendIntervalMs(request.getResendIntervalMs())
                .createdAt(now)
                .updatedAt(now)
                .build();
    }

    private static Alert applyRaise(Alert existing, RaiseAlertRequest request, Instant now) {
        existing.setCount(existing.getCount() + 1);
        existing.setSubject(request.getSubject());
        existing.setBody(request.getBody());
        if (request.getRecipients() != null) {
            existing.setRecipients(request.getRecipients());
        }
        if (request.getSeverity() != null) {
            existing.setSeverity(request.getSeverity());
        }
        if (request.getMetadata() != null && !request.getMetadata().isEmpty()) {
            if (existing.getMetadata() == null) {
                existing.setMetadata(new HashMap<>());
            }
            existing.getMetadata().putAll(request.getMetadata());
        }
        if (request.getResendIntervalMs() != null) {
            existing.setResendIntervalMs(request.getResendIntervalMs());
        }
        if (existing.getState() == AlertState.RESOLVED) {
            existing.setState(AlertState.FIRING);
            existing.setResolvedAt(null);
            existing.setAcknowledgedAt(null);
            existing.setAcknowledgedBy(null);
            existing.setSilencedAt(null);
            existing.setSilencedBy(null);
            existing.setLastTriggeredAt(null);
        }
        existing.setUpdatedAt(now);
        return existing;
    }

    private static HashMap<String, String> copyMetadata(RaiseAlertRequest request) {
        return request.getMetadata() != null ? new HashMap<>(request.getMetadata()) : new HashMap<>();
    }
}
