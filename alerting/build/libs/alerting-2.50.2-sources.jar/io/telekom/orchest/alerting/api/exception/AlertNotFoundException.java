package io.telekom.orchest.alerting.api.exception;

/**
 * Raised when an alert id does not exist.
 */
public class AlertNotFoundException extends RuntimeException {

    public AlertNotFoundException(String id) {
        super("Alert not found: " + id);
    }
}
