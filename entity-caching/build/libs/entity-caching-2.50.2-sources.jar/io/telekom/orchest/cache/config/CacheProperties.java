package io.telekom.orchest.cache.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Binds {@code telekom.cache.*} from application.yml. Each entry under {@code caches.<name>}
 * is an override for the programmatically-registered {@link io.telekom.orchest.cache.core.CacheDefinition}
 * sharing the same name — allowing ops to tune refresh cadence without a code change.
 */
@ConfigurationProperties(prefix = "orchest.caching")
public class CacheProperties {

    /** Master kill switch for the entire library. */
    private boolean enabled = true;

    /** Size of the scheduler pool driving periodic refreshes. */
    private int schedulerPoolSize = 2;

    /** Per-cache overrides keyed by cache name. */
    private Map<String, CacheConfig> caches = new LinkedHashMap<>();

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean v) { this.enabled = v; }

    public int getSchedulerPoolSize() { return schedulerPoolSize; }
    public void setSchedulerPoolSize(int v) { this.schedulerPoolSize = v; }

    public Map<String, CacheConfig> getCaches() { return caches; }
    public void setCaches(Map<String, CacheConfig> caches) { this.caches = caches; }

    public static class CacheConfig {
        private Boolean enabled;
        private Duration refreshInterval;
        private Duration initialDelay;
        private Boolean loadOnStartup;
        private Boolean failSafe;
        private Integer retryAttempts;
        private Duration retryBackoff;

        public Boolean getEnabled() { return enabled; }
        public void setEnabled(Boolean v) { this.enabled = v; }
        public Duration getRefreshInterval() { return refreshInterval; }
        public void setRefreshInterval(Duration v) { this.refreshInterval = v; }
        public Duration getInitialDelay() { return initialDelay; }
        public void setInitialDelay(Duration v) { this.initialDelay = v; }
        public Boolean getLoadOnStartup() { return loadOnStartup; }
        public void setLoadOnStartup(Boolean v) { this.loadOnStartup = v; }
        public Boolean getFailSafe() { return failSafe; }
        public void setFailSafe(Boolean v) { this.failSafe = v; }
        public Integer getRetryAttempts() { return retryAttempts; }
        public void setRetryAttempts(Integer v) { this.retryAttempts = v; }
        public Duration getRetryBackoff() { return retryBackoff; }
        public void setRetryBackoff(Duration v) { this.retryBackoff = v; }
    }
}
