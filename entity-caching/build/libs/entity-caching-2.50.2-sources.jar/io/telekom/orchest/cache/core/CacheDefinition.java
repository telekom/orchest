package io.telekom.orchest.cache.core;

import java.time.Duration;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Immutable description of a cache bean: how to load, how to key it, and how often to refresh.
 *
 * <p>Construct via the {@link Builder}. The sealed-like builder enforces the required
 * fields (name, loader, keyExtractor) at build time.
 *
 * @param <K> cache key
 * @param <E> source entity as returned by the loader
 * @param <V> cached value (may equal E, or be a DTO after transform)
 */
public final class CacheDefinition<K, E, V> {

    private final String name;
    private final CacheLoader<E> loader;
    private final KeyExtractor<K, V> keyExtractor;
    private final Function<E, V> transform;
    private final Predicate<E> filter;
    private final Duration refreshInterval;
    private final Duration initialDelay;
    private final boolean loadOnStartup;
    private final boolean failSafe;
    private final int retryAttempts;
    private final Duration retryBackoff;
    private final CacheHooks<K, V> hooks;

    private CacheDefinition(Builder<K, E, V> b) {
        this.name = Objects.requireNonNull(b.name, "cache name");
        this.loader = Objects.requireNonNull(b.loader, "loader");
        this.keyExtractor = Objects.requireNonNull(b.keyExtractor, "keyExtractor");
        this.transform = b.transform;
        this.filter = b.filter;
        this.refreshInterval = b.refreshInterval;
        this.initialDelay = b.initialDelay;
        this.loadOnStartup = b.loadOnStartup;
        this.failSafe = b.failSafe;
        this.retryAttempts = b.retryAttempts;
        this.retryBackoff = b.retryBackoff;
        this.hooks = b.hooks == null ? CacheHooks.noop() : b.hooks;
    }

    public String name() { return name; }
    public CacheLoader<E> loader() { return loader; }
    public KeyExtractor<K, V> keyExtractor() { return keyExtractor; }
    public Function<E, V> transform() { return transform; }
    public Predicate<E> filter() { return filter; }
    public Duration refreshInterval() { return refreshInterval; }
    public Duration initialDelay() { return initialDelay; }
    public boolean loadOnStartup() { return loadOnStartup; }
    public boolean failSafe() { return failSafe; }
    public int retryAttempts() { return retryAttempts; }
    public Duration retryBackoff() { return retryBackoff; }
    public CacheHooks<K, V> hooks() { return hooks; }

    public static <K, E, V> Builder<K, E, V> builder() {
        return new Builder<>();
    }

    public static final class Builder<K, E, V> {
        private String name;
        private CacheLoader<E> loader;
        private KeyExtractor<K, V> keyExtractor;
        private Function<E, V> transform;
        private Predicate<E> filter;
        private Duration refreshInterval = Duration.ofMinutes(5);
        private Duration initialDelay = Duration.ZERO;
        private boolean loadOnStartup = true;
        private boolean failSafe = true;
        private int retryAttempts = 0;
        private Duration retryBackoff = Duration.ofSeconds(1);
        private CacheHooks<K, V> hooks;

        public Builder<K, E, V> name(String name) { this.name = name; return this; }
        public Builder<K, E, V> loader(CacheLoader<E> loader) { this.loader = loader; return this; }
        public Builder<K, E, V> keyExtractor(KeyExtractor<K, V> ke) { this.keyExtractor = ke; return this; }
        public Builder<K, E, V> transform(Function<E, V> t) { this.transform = t; return this; }
        public Builder<K, E, V> filter(Predicate<E> p) { this.filter = p; return this; }
        public Builder<K, E, V> refreshInterval(Duration d) { this.refreshInterval = d; return this; }
        public Builder<K, E, V> initialDelay(Duration d) { this.initialDelay = d; return this; }
        public Builder<K, E, V> loadOnStartup(boolean v) { this.loadOnStartup = v; return this; }
        public Builder<K, E, V> failSafe(boolean v) { this.failSafe = v; return this; }
        public Builder<K, E, V> retryAttempts(int v) { this.retryAttempts = v; return this; }
        public Builder<K, E, V> retryBackoff(Duration d) { this.retryBackoff = d; return this; }
        public Builder<K, E, V> hooks(CacheHooks<K, V> h) { this.hooks = h; return this; }

        public CacheDefinition<K, E, V> build() {
            return new CacheDefinition<>(this);
        }
    }
}
