package io.telekom.orchest.cache.config;

import io.telekom.orchest.cache.core.Cache;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Runtime registry of all cache beans created by the starter. Host applications can
 * inject this to look caches up by name (e.g., from an admin controller).
 */
public class CacheRegistry {

    private final Map<String, Cache<?, ?>> caches = new ConcurrentHashMap<>();

    public void register(Cache<?, ?> cache) { caches.put(cache.name(), cache); }

    @SuppressWarnings("unchecked")
    public <K, V> Optional<Cache<K, V>> find(String name) {
        return Optional.ofNullable((Cache<K, V>) caches.get(name));
    }

    public Collection<Cache<?, ?>> all() { return caches.values(); }
}
