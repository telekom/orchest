package io.telekom.orchest.cache.core;

public class CacheException extends RuntimeException {
    public CacheException(String message, Throwable cause) {
        super(message, cause);
    }
    public CacheException(String message) {
        super(message);
    }
}