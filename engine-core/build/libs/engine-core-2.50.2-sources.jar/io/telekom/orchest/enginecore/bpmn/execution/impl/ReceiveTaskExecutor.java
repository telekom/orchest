package io.telekom.orchest.enginecore.bpmn.execution.impl;

import io.telekom.orchest.api.core.adapters.data.model.ProcessInstance;
import io.telekom.orchest.enginecore.bpmn.execution.ExecutionContext;
import io.telekom.orchest.enginecore.bpmn.execution.NodeExecutor;
import io.telekom.orchest.api.core.model.bpmn.node.BaseNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ReceiveTaskExecutor implements NodeExecutor {
    private static final Logger log = LoggerFactory.getLogger(ReceiveTaskExecutor.class);

    @Override
    public void execute(ProcessInstance instance, BaseNode node, ExecutionContext context) {
        log.info("Reached Receive Task: {}. Waiting for message...", node.getName());
    }
}
