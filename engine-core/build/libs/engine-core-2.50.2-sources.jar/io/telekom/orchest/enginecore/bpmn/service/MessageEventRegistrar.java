package io.telekom.orchest.enginecore.bpmn.service;

import io.telekom.orchest.api.core.adapters.data.model.MessageEventStore;
import io.telekom.orchest.api.core.adapters.data.repository.MessageEventRepository;
import io.telekom.orchest.api.core.model.bpmn.IntermediateEventState;
import io.telekom.orchest.api.core.model.bpmn.node.BaseNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

/**
 * Handles all message-related event registration: intermediate message events,
 * start message events, and gateway-linked message events.
 */
@Slf4j
@RequiredArgsConstructor
public class MessageEventRegistrar {

    private final MessageEventRepository messageEventRepository;

    public void registerStartMessageEvent(String messageName, BaseNode messageNode, String processDefinitionId) {
        Optional<MessageEventStore> existing = messageEventRepository.findStartMessageEvent(processDefinitionId);
        MessageEventStore messageEventStore;
        if (existing.isPresent()) {
            messageEventStore = existing.get();
            messageEventStore.setMessageName(messageName);
        } else {
            messageEventStore = MessageEventStore.builder()
                    .state(IntermediateEventState.REGISTERED)
                    .messageName(messageName)
                    .nodeInformation(messageNode)
                    .processDefinitionId(processDefinitionId)
                    .isStartEvent(true)
                    .build();
        }
        messageEventRepository.registerEvent(messageEventStore);
    }

    public MessageEventStore registerMessageEvent(String messageName, String correlationValue,
                                                   String processInstanceId, BaseNode messageNode) {
        return registerMessageEvent(messageName, correlationValue, processInstanceId, messageNode, null, false);
    }

    public MessageEventStore registerMessageEvent(String messageName, String correlationValue,
                                                   String processInstanceId, BaseNode messageNode,
                                                   String processDefinitionId, boolean isStartEvent) {
        MessageEventStore messageEventStore = MessageEventStore.builder()
                .processInstanceId(processInstanceId)
                .state(IntermediateEventState.REGISTERED)
                .messageName(messageName)
                .correlationKey(correlationValue)
                .nodeInformation(messageNode)
                .processDefinitionId(processDefinitionId)
                .isStartEvent(isStartEvent)
                .build();
        return messageEventRepository.registerEvent(messageEventStore);
    }

    public MessageEventStore registerMessageEventForGateway(String messageName, String correlationValue,
                                                             String processInstanceId, BaseNode messageNode,
                                                             String linkedEventId) {
        MessageEventStore messageEventStore = MessageEventStore.builder()
                .processInstanceId(processInstanceId)
                .state(IntermediateEventState.REGISTERED)
                .messageName(messageName)
                .correlationKey(correlationValue)
                .nodeInformation(messageNode)
                .isLinkedEvent(true)
                .linkedEventId(linkedEventId)
                .build();
        return messageEventRepository.registerEvent(messageEventStore);
    }

    public void deleteStartEventByDefinitionId(String definitionId) {
        messageEventRepository.deleteStartEventByDefinitionId(definitionId);
    }

    public void deleteByLinkedEventId(String linkedEventId) {
        messageEventRepository.deleteByLinkedEventId(linkedEventId);
    }

    public void deleteByProcessInstanceId(String processInstanceId) {
        messageEventRepository.deleteByProcessInstanceId(processInstanceId);
    }
}
