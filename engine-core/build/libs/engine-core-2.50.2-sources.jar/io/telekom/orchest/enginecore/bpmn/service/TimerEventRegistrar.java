package io.telekom.orchest.enginecore.bpmn.service;

import io.telekom.orchest.api.core.adapters.data.dto.WorkerEventRequest;
import io.telekom.orchest.api.core.adapters.data.model.ProcessInstance;
import io.telekom.orchest.api.core.adapters.data.model.TimedEvent;
import io.telekom.orchest.api.core.adapters.data.repository.TimedEventRepository;
import io.telekom.orchest.api.core.model.bpmn.IntermediateEventState;
import io.telekom.orchest.api.core.model.bpmn.NodeState;
import io.telekom.orchest.api.core.model.bpmn.node.BaseNode;
import io.telekom.orchest.api.core.utils.IsoDateTimeParser;
import io.telekom.orchest.api.core.utils.StateChangeUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Handles all timer-related event registration: intermediate timer events,
 * start timer events, gateway-linked timer events, progressive retry timers,
 * and cycled timer re-registration.
 */
@Slf4j
@RequiredArgsConstructor
public class TimerEventRegistrar {

    private final TimedEventRepository timedEventRepository;

    public void registerCycledTimedEvent(TimedEvent timedEvent) {
        timedEvent.setTriggerAt(getTriggerAt(timedEvent.getValue()));
        timedEventRepository.registerEvent(timedEvent);
    }

    public TimedEvent registerTimerEvent(ProcessInstance processInstance, String duration, BaseNode node) {
        TimedEvent timedEvent = TimedEvent.builder()
                .processInstanceId(processInstance.getProcessInstanceId())
                .state(IntermediateEventState.REGISTERED)
                .type(TimedEvent.Type.TIMER)
                .value(duration)
                .triggerAt(getTriggerAt(duration))
                .nodeInformation(node)
                .stateChanges(List.of(StateChangeUtils.buildStateChanges(NodeState.REGISTERED)))
                .build();
        return timedEventRepository.registerEvent(timedEvent);
    }

    public TimedEvent registerStartTimerEvent(String duration, BaseNode node, String definitionId, Integer version) {
        Optional<TimedEvent> startTimedEvent = timedEventRepository.findStartTimedEvent(definitionId);

        TimedEvent timedEvent;
        if (startTimedEvent.isPresent()) {
            timedEvent = startTimedEvent.get();
            timedEvent.setTriggerAt(getTriggerAt(duration));
            timedEvent.setValue(duration);
        } else {
            timedEvent = TimedEvent.builder()
                    .processDefinitionId(definitionId)
                    .version(version)
                    .state(IntermediateEventState.REGISTERED)
                    .type(TimedEvent.Type.START_EVENT_TIMER)
                    .isStartEvent(true)
                    .value(duration)
                    .triggerAt(getTriggerAt(duration))
                    .nodeInformation(node)
                    .stateChanges(List.of(StateChangeUtils.buildStateChanges(NodeState.REGISTERED)))
                    .build();
        }
        return timedEventRepository.registerEvent(timedEvent);
    }

    public TimedEvent registerTimerEventForGateway(ProcessInstance processInstance, String duration,
                                                    BaseNode node, String linkedEventId) {
        TimedEvent timedEvent = TimedEvent.builder()
                .processInstanceId(processInstance.getProcessInstanceId())
                .state(IntermediateEventState.REGISTERED)
                .type(TimedEvent.Type.TIMER)
                .value(duration)
                .triggerAt(getTriggerAt(duration))
                .nodeInformation(node)
                .isLinkedEvent(true)
                .linkedEventId(linkedEventId)
                .stateChanges(List.of(StateChangeUtils.buildStateChanges(NodeState.REGISTERED)))
                .build();
        return timedEventRepository.registerEvent(timedEvent);
    }

    public void clearEvent(TimedEvent timedEvent) {
        timedEventRepository.remove(timedEvent);
    }

    public void registerProgressiveRetry(String processInstanceId, Duration retryBackOff, WorkerEventRequest workerEventRequest) {
        workerEventRequest.setState(NodeState.PENDING);
        workerEventRequest.getStateChanges().add(StateChangeUtils.buildStateChanges(NodeState.PENDING));
        workerEventRequest.setRetryBackOff(null);
        Optional<TimedEvent> duplicateEvent = timedEventRepository.isDuplicateEvent(processInstanceId, workerEventRequest.getActivityId());
        if (duplicateEvent.isPresent()) {
            log.warn("received duplicate task retry event for processInstanceId: {}, activityId: {}", processInstanceId, workerEventRequest.getActivityId());
            return;
        }
        timedEventRepository.registerEvent(TimedEvent.builder()
                .processInstanceId(processInstanceId)
                .state(IntermediateEventState.REGISTERED)
                .type(TimedEvent.Type.TASK_RETRY)
                .value(retryBackOff.toString())
                .triggerAt(LocalDateTime.now().plus(retryBackOff))
                .stateChanges(List.of(StateChangeUtils.buildStateChanges(NodeState.REGISTERED)))
                .eventRequest(workerEventRequest)
                .build());
    }

    public void cleanupPendingRetryTimers(String processInstanceId) {
        log.info("Cleaning up pending retry timers for instance {}", processInstanceId);
        timedEventRepository.deletePendingRetryTimersByProcessInstanceId(processInstanceId);
    }

    public void deleteStartEventByDefinitionId(String definitionId) {
        timedEventRepository.deleteStartEventByDefinitionId(definitionId);
    }

    public void deleteByLinkedEventId(String linkedEventId) {
        timedEventRepository.deleteByLinkedEventId(linkedEventId);
    }

    private LocalDateTime getTriggerAt(String timerExpression) {
        return IsoDateTimeParser.parseToLocalDateTime(timerExpression);
    }
}
