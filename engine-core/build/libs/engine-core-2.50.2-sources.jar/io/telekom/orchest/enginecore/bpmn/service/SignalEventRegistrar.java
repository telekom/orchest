package io.telekom.orchest.enginecore.bpmn.service;

import io.telekom.orchest.api.core.adapters.data.model.SignalEvent;
import io.telekom.orchest.api.core.adapters.data.repository.SignalEventRepository;
import io.telekom.orchest.api.core.model.bpmn.IntermediateEventState;
import io.telekom.orchest.api.core.model.bpmn.node.BaseNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

/**
 * Handles all signal-related event registration: intermediate signal events,
 * start signal events, and gateway-linked signal events.
 */
@Slf4j
@RequiredArgsConstructor
public class SignalEventRegistrar {

    private final SignalEventRepository signalEventRepository;

    public SignalEvent registerStartSignalEvent(String signalName, BaseNode signalNode, String processDefinitionId) {
        Optional<SignalEvent> existing = signalEventRepository.findSignalStartEvent(processDefinitionId);
        SignalEvent signalEvent;
        if (existing.isPresent()) {
            signalEvent = existing.get();
            signalEvent.setSignalName(signalName);
        } else {
            signalEvent = SignalEvent.builder()
                    .state(IntermediateEventState.REGISTERED)
                    .signalName(signalName)
                    .nodeInformation(signalNode)
                    .isStartEvent(true)
                    .processDefinitionId(processDefinitionId)
                    .build();
        }
        return signalEventRepository.registerEvent(signalEvent);
    }

    public SignalEvent registerSignalEvent(String signalName, String processInstanceId,
                                            BaseNode signalNode, String processDefinitionId, boolean isStartEvent) {
        SignalEvent signalEvent = SignalEvent.builder()
                .processInstanceId(processInstanceId)
                .state(IntermediateEventState.REGISTERED)
                .signalName(signalName)
                .nodeInformation(signalNode)
                .isStartEvent(isStartEvent)
                .processDefinitionId(processDefinitionId)
                .build();
        return signalEventRepository.registerEvent(signalEvent);
    }

    public SignalEvent registerSignalEventForGateway(String signalName, String processInstanceId,
                                                      BaseNode signalNode, String linkedEventId) {
        SignalEvent signalEvent = SignalEvent.builder()
                .processInstanceId(processInstanceId)
                .state(IntermediateEventState.REGISTERED)
                .signalName(signalName)
                .nodeInformation(signalNode)
                .isLinkedEvent(true)
                .linkedEventId(linkedEventId)
                .build();
        return signalEventRepository.registerEvent(signalEvent);
    }

    public void deleteStartEventByDefinitionId(String definitionId) {
        signalEventRepository.deleteStartEventByDefinitionId(definitionId);
    }

    public void deleteByLinkedEventId(String linkedEventId) {
        signalEventRepository.deleteByLinkedEventId(linkedEventId);
    }

    public void deleteByProcessInstanceId(String processInstanceId) {
        signalEventRepository.deleteByProcessInstanceId(processInstanceId);
    }
}
