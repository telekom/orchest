package io.telekom.orchest.enginecore.bpmn.eventhandler;


import io.telekom.orchest.api.core.request.RetryProcessEvent;
import io.telekom.orchest.enginecore.bpmn.OrchestWorkflowEngine;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IRetryProcessInstanceEventHandler implements EventHandler<RetryProcessEvent, Void> {
    private final OrchestWorkflowEngine orchestWorkflowEngine;

    @Override
    public Void execute(RetryProcessEvent data) {
        orchestWorkflowEngine.retryActivity(data);
        return null;
    }
}