package io.telekom.orchest.enginecore.bpmn.service;


import io.telekom.orchest.api.core.adapters.data.model.DecisionInstance;
import io.telekom.orchest.api.core.adapters.data.repository.DecisionInstanceRepository;
import io.telekom.orchest.telemetry.metrics.MetricKey;
import io.telekom.orchest.telemetry.metrics.MetricType;
import io.telekom.orchest.telemetry.metrics.MetricsRecorder;
import io.telekom.orchest.telemetry.metrics.NoOpMetricsRecorder;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

@Slf4j
public class DecisionInstanceService {

    private final DecisionInstanceRepository decisionInstanceRepository;
    private final MetricsRecorder metricsRecorder;

    public DecisionInstanceService(DecisionInstanceRepository decisionInstanceRepository,
                                   MetricsRecorder metricsRecorder) {
        this.decisionInstanceRepository = decisionInstanceRepository;
        this.metricsRecorder = metricsRecorder == null ? NoOpMetricsRecorder.INSTANCE : metricsRecorder;
    }

    public List<DecisionInstance> getAll() {
        return decisionInstanceRepository.getDecisionInstances();
    }

    public Optional<DecisionInstance> getDecisionById(String decisionInstanceId) {
        return decisionInstanceRepository.getById(decisionInstanceId);
    }

    public DecisionInstance save(DecisionInstance decisionInstance) {
        return decisionInstanceRepository.save(decisionInstance);
    }

    /**
     * Records a single DMN evaluation in the persistent metrics pipeline.
     *
     * <p>Kept as an explicit method (rather than hooking inside {@link #save(DecisionInstance)})
     * so that future state-update saves on a {@code DecisionInstance} don't accidentally
     * over-count evaluations.
     */
    public void recordEvaluation(DecisionInstance decisionInstance) {
        if (decisionInstance == null) {
            return;
        }
        metricsRecorder.increment(MetricKey.of(MetricType.DECISION_INSTANCE_EVALUATED,
                decisionInstance.getDefinitionId(), decisionInstance.getVersion()));
    }
}
