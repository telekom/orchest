package io.telekom.orchest.logging;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@NoArgsConstructor
@Configuration("loggingProperties")
@ConfigurationProperties(prefix = "logging")
public class ModuleProperties {

    private String format;
}
