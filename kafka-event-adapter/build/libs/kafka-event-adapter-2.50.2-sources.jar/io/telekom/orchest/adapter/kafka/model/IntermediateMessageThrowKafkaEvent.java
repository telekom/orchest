package io.telekom.orchest.adapter.kafka.model;

import io.telekom.orchest.adapter.kafka.KafkaUtils;
import io.telekom.orchest.api.core.request.MessageEventRequest;
import lombok.Setter;

import java.util.Map;

import static io.telekom.orchest.adapter.kafka.client.TopicConstant.SERVER_INTERMEDIATE_MESSAGE_THROW_EVENT_TOPIC;


@Setter
public class IntermediateMessageThrowKafkaEvent implements KafkaEvent<MessageEventRequest> {

    private MessageEventRequest messageEventRequest;

    @Override
    public String getTopicName() {
        return KafkaUtils.getTopicWithEnvSuffix(SERVER_INTERMEDIATE_MESSAGE_THROW_EVENT_TOPIC);
    }

    @Override
    public MessageEventRequest getValue() {
        return messageEventRequest;
    }

    @Override
    public Map<String, String> getHeaders() {
        return Map.of();
    }
}
