package io.telekom.orchest.adapter.kafka.model;

import io.telekom.orchest.adapter.kafka.KafkaUtils;
import io.telekom.orchest.api.core.request.SignalEventRequest;
import lombok.Setter;

import java.util.Map;

import static io.telekom.orchest.adapter.kafka.client.TopicConstant.SERVER_INTERMEDIATE_SIGNAL_THROW_EVENT_TOPIC;


@Setter
public class IntermediateSignalThrowKafkaEvent implements KafkaEvent<SignalEventRequest> {

    private SignalEventRequest signalEventRequest;

    @Override
    public String getTopicName() {
        return KafkaUtils.getTopicWithEnvSuffix(SERVER_INTERMEDIATE_SIGNAL_THROW_EVENT_TOPIC);
    }

    @Override
    public SignalEventRequest getValue() {
        return signalEventRequest;
    }

    @Override
    public Map<String, String> getHeaders() {
        return Map.of();
    }
}
