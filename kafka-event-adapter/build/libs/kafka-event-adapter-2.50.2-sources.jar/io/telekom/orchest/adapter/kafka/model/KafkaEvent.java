package io.telekom.orchest.adapter.kafka.model;

import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.header.internals.RecordHeaders;

import java.util.Map;
import java.util.UUID;

public interface KafkaEvent<T> extends IEventRecordDTO<T> {

    default String getKey() {
        return UUID.randomUUID().toString();
    }

    default Headers getRecordHeaders() {
        Headers recordHeaders = new RecordHeaders();
        Map<String, String> headers = getHeaders();
        if (headers != null) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                recordHeaders.add(entry.getKey(), entry.getValue().getBytes());
            }
        }
        return recordHeaders;
    }
}
