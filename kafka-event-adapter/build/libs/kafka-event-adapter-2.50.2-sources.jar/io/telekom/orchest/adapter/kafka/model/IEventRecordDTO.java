package io.telekom.orchest.adapter.kafka.model;

import java.util.Map;

public interface IEventRecordDTO<T> {
    String getKey();

    String getTopicName();

    T getValue();

    Map<String, String> getHeaders();
}
