package io.telekom.orchest.adapter.kafka.client;

public interface IEncryptionClient {

    String encrypt(String plainText);
    String decrypt(String cipherText);
    boolean isEncryptionEnabled();

}
