package io.telekom.orchest.adapter.kafka.model;

import io.telekom.orchest.adapter.kafka.KafkaUtils;
import io.telekom.orchest.api.core.request.PendingTaskRequest;
import lombok.Setter;

import java.util.Map;

import static io.telekom.orchest.adapter.kafka.client.TopicConstant.SERVER_PENDING_TASK_EVENT_TOPIC;


@Setter
public class PendingTaskKafkaEvent implements KafkaEvent<PendingTaskRequest> {

    private PendingTaskRequest pendingTaskRequest;

    @Override
    public String getTopicName() {
        return KafkaUtils.getTopicWithEnvSuffix(SERVER_PENDING_TASK_EVENT_TOPIC);
    }

    @Override
    public PendingTaskRequest getValue() {
        return pendingTaskRequest;
    }

    @Override
    public Map<String, String> getHeaders() {
        return Map.of();
    }
}
