package io.telekom.orchest.adapter.kafka.client;

import de.telekom.solutions.kmsclient.CryptoService;
import de.telekom.solutions.kmsclient.api.CipherType;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import static io.telekom.orchest.adapter.kafka.client.KafkaConstant.ORCHEST_KAFKA_CRYPTO_SERVICE_BEAN_NAME;

@Component
public class KafkaEncryptionClient implements IEncryptionClient {

    private final CryptoService cryptoService;

    public KafkaEncryptionClient(@Qualifier(ORCHEST_KAFKA_CRYPTO_SERVICE_BEAN_NAME) CryptoService cryptoService) {
        this.cryptoService = cryptoService;
    }

    @Override
    public String encrypt(String data) {
        return cryptoService.cipher(CipherType.ENCRYPT, data);
    }

    @Override
    public String decrypt(String data) {
        return cryptoService.cipher(CipherType.DECRYPT, data);

    }

    @Override
    public boolean isEncryptionEnabled() {
        return cryptoService.isEnabled();
    }
}
