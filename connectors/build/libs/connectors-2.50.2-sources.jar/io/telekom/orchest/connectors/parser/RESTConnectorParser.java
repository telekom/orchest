package io.telekom.orchest.connectors.parser;

import io.camunda.zeebe.model.bpmn.instance.FlowNode;
import io.telekom.orchest.api.core.model.bpmn.node.BaseNode;
import io.telekom.orchest.connectors.ConnectorParser;

import static io.telekom.orchest.connectors.BpmnConnectorParser.mapIoMappings;


public class RESTConnectorParser implements ConnectorParser {
    @Override
    public void parse(FlowNode flowNode, BaseNode node) {
        mapIoMappings(flowNode, node);
    }
}
