package io.telekom.orchest.adapter.mongo.mapper;


import io.telekom.orchest.adapter.mongo.model.WorkerRegistry;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface WorkerRegistryMapper {

    WorkerRegistry toDocument(io.telekom.orchest.api.core.adapters.data.model.WorkerRegistry domain);

    io.telekom.orchest.api.core.adapters.data.model.WorkerRegistry toDomain(WorkerRegistry document);

}
