package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.MessageEventStore;
import io.telekom.orchest.api.core.model.bpmn.IntermediateEventState;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data MongoDB repository for {@link MessageEventStore} documents.
 * Handles querying message subscriptions by name, correlation key, and state.
 */
@Repository
public interface MongoMessageEventRepository extends MongoRepository<MessageEventStore, String> {

    List<MessageEventStore> findAllByMessageNameAndCorrelationKeyAndState(String messageName, String correlationKey, IntermediateEventState state);

    Optional<MessageEventStore> findByMessageNameAndCorrelationKeyAndState(String messageName, String correlationKey, IntermediateEventState state);

    Optional<MessageEventStore> findByMessageNameAndIsStartEvent(String messageName, Boolean isStartEvent);

    Optional<MessageEventStore> findMessageEventStoreByProcessDefinitionIdAndIsStartEvent(String processDefinitionId, Boolean isStartEvent);

    void deleteByLinkedEventId(String linkedEventId);

    void deleteByProcessDefinitionIdAndIsStartEvent(String processDefinitionId, Boolean isStartEvent);

    void deleteByProcessInstanceId(String processInstanceId);
}
