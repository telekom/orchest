package io.telekom.orchest.adapter.mongo.model;

import io.telekom.orchest.telemetry.metrics.MetricType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

/**
 * Mongo persistence shape for one lifetime metric total.
 *
 * <p>The document {@code _id} is {@link io.telekom.orchest.telemetry.metrics.MetricKey#stableId()}
 * — a deterministic, human-readable string. Using the natural key as {@code _id} makes
 * the upsert filter free (no extra index needed for the write path) and lets ops
 * grep collection contents directly.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document
public class MetricLifetimeTotalDocument {

    @Id
    private String id;
    private MetricType metricType;
    private String definitionId;
    private Integer version;
    private long count;

    private Instant firstObservedAt;
    private Instant lastUpdatedAt;
}
