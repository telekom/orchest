package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.ProcessInstance;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data MongoDB repository for {@link ProcessInstance} documents.
 * Manages the persistence of process execution state.
 */
@Repository
public interface MongoProcessInstanceRepository extends MongoRepository<ProcessInstance, String> {

    Optional<ProcessInstance> findByProcessInstanceId(String processInstanceId);

    @Query(value = "{ 'parentProcesActivity.processInstanceId': ?0}", fields = "processInstanceId")
    List<ProcessInstance> findAllChildInstanceIds(String parentProcessInstanceId);

    @Query(value = "{ 'parentProcesActivity.processInstanceId': ?0, 'state': { $in: ['STARTED', 'RUNNING', 'HOLD', 'INCIDENT'] } }", fields = "processInstanceId")
    List<ProcessInstance> hasActiveChildInstances(String parentProcessInstanceId);
}
