package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.WorkerRegistry;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data MongoDB repository for {@link WorkerRegistry} documents.
 * Tracks registered worker namespaces and their capabilities.
 */
@Repository
public interface MongoWorkerRegistryRepository extends MongoRepository<WorkerRegistry, String> {

    List<WorkerRegistry> findAllByProcessDefinitionId(String processDefinitionId);

    Optional<WorkerRegistry> findByNameSpace(String nameSpace);
}
