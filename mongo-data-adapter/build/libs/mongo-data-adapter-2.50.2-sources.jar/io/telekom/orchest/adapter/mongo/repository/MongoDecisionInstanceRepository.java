package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.DecisionInstance;
import io.telekom.orchest.api.core.model.dmn.DIState;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Spring Data MongoDB repository for {@link DecisionInstance} documents.
 * Manages the storage and retrieval of historical decision executions.
 */
@Repository
public interface MongoDecisionInstanceRepository extends MongoRepository<DecisionInstance, String> {

    Optional<DecisionInstance> findByDecisionInstanceId(String decisionInstanceId);

    List<DecisionInstance> findAllByStateAndExecutedAtBefore(DIState state, OffsetDateTime executedAt);

    /**
     * Streams expired decision instances over a server-side cursor so callers can process them
     * one at a time without materializing the entire (potentially huge) result set on the heap.
     * The returned stream MUST be closed (use try-with-resources) to release the underlying cursor.
     */
    Stream<DecisionInstance> streamAllByStateAndExecutedAtBefore(DIState state, OffsetDateTime executedAt);

    void deleteAllByStateAndExecutedAtBefore(DIState state, OffsetDateTime executedAtAfter);

}
