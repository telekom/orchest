package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.ProcessDefinition;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data MongoDB repository for {@link ProcessDefinition} documents.
 * Provides custom query methods for finding definitions by ID and version.
 */
@Repository
public interface MongoProcessDefinitionRepository extends MongoRepository<ProcessDefinition, String> {

    List<ProcessDefinition> findAllByDefinitionId(String definitionId);
    Optional<ProcessDefinition> findFirstByDefinitionIdOrderByVersionDesc(String definitionId);
    Optional<ProcessDefinition> findByDefinitionIdAndVersion(String definitionId, Integer version);
    @Aggregation(pipeline = {
            "{ '$group': { '_id': '$definitionId' }}",
            "{ '$project': { 'definitionId': '$_id' } }"
    })
    List<ProcessDefinition> findDistinctProcessIds();

    Long deleteByDefinitionIdAndVersion(String definitionId, Integer version);
}
