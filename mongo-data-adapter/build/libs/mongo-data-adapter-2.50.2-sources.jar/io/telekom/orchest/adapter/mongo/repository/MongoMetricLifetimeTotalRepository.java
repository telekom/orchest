package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.MetricLifetimeTotalDocument;
import io.telekom.orchest.telemetry.metrics.MetricType;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data Mongo handle for the {@code metric_lifetime_totals} collection. The
 * write path does not go through this interface — flushes use raw {@code BulkOperations}
 * with {@code $inc} for atomicity. This interface only serves the read API.
 */
public interface MongoMetricLifetimeTotalRepository extends MongoRepository<MetricLifetimeTotalDocument, String> {

    List<MetricLifetimeTotalDocument> findAllByMetricType(MetricType metricType);

    List<MetricLifetimeTotalDocument> findAllByMetricTypeAndDefinitionId(MetricType metricType, String definitionId);

    List<MetricLifetimeTotalDocument> findAllByDefinitionId(String definitionId);

    Optional<MetricLifetimeTotalDocument> findById(String id);
}
