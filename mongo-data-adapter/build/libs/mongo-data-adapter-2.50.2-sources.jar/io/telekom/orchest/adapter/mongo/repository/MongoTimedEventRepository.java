package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.TimedEvent;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data MongoDB repository for {@link TimedEvent} documents.
 * Stores detailed information about registered timer events.
 */
@Repository
public interface MongoTimedEventRepository extends MongoRepository<TimedEvent, String> {

    Optional<TimedEvent> findByTimedEventRegistryId(String timedEventRegistryId);

    Optional<TimedEvent> findByProcessDefinitionIdAndIsStartEvent(String processDefinitionId, boolean isStartEvent);

    /**
     * Returns all rows that match {@code processDefinitionId} and {@code isStartEvent} so the
     * adapter can cancel the corresponding scheduler tasks before the rows are removed. The
     * {@code @Query} annotation disambiguates this from the singleton {@code findBy...} method
     * above (Spring Data otherwise picks one or the other based on return type).
     */
    @Query("{ 'processDefinitionId': ?0, 'isStartEvent': ?1 }")
    List<TimedEvent> listByProcessDefinitionIdAndIsStartEvent(String processDefinitionId, boolean isStartEvent);

    List<TimedEvent> findByLinkedEventId(String linkedEventId);

    void deleteByLinkedEventId(String linkedEventId);

    void deleteTimedEventsByProcessDefinitionIdAndIsStartEvent(String processDefinitionId, boolean isStartEvent);

    List<TimedEvent> findByProcessInstanceIdAndType(String processInstanceId, TimedEvent.Type type);

    void deleteByProcessInstanceIdAndType(String processInstanceId, TimedEvent.Type type);

    @Query("{ 'eventRequest.processInstanceId': ?0, 'eventRequest.activityId': ?1, 'type': 'TASK_RETRY' }")
    Optional<TimedEvent> isDuplicateTaskRetryEvent(String processInstanceId, String activityId);
}
