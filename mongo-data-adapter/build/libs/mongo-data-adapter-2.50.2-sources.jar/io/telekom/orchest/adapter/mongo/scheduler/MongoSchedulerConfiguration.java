package io.telekom.orchest.adapter.mongo.scheduler;

import io.telekom.orchest.scheduling.spi.ScheduledTaskStore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoOperations;

import java.time.Clock;

/**
 * Wires the Mongo-backed {@link ScheduledTaskStore} into any service that depends on
 * {@code mongo-data-adapter}.
 *
 * <p>Gated by {@code orchest.scheduler.enabled} (default true) so a host that wants to opt out can
 * do so cleanly without having to exclude packages.
 */
@Configuration
@ConditionalOnProperty(prefix = "orchest.scheduler", name = "enabled", havingValue = "true", matchIfMissing = true)
public class MongoSchedulerConfiguration {

    @Bean
    @ConditionalOnMissingBean(Clock.class)
    public Clock schedulerClock() {
        return Clock.systemUTC();
    }

    @Bean
    @ConditionalOnMissingBean(ScheduledTaskStore.class)
    public ScheduledTaskStore mongoScheduledTaskStore(MongoOperations mongoOperations, Clock schedulerClock) {
        return new MongoScheduledTaskStore(mongoOperations, schedulerClock);
    }
}
