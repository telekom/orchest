package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.ActivityStateMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoActivityStateRepository;
import io.telekom.orchest.api.core.adapters.data.model.ActivityState;
import io.telekom.orchest.api.core.adapters.data.repository.ActivityStateRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class MongoActivityStateRepositoryAdapter implements ActivityStateRepository {

    private final MongoActivityStateRepository repository;
    private final ActivityStateMapper mapper;

    @Override
    public List<ActivityState> findAll() {
        return repository.findAll().stream().map(mapper::toDomain).toList();
    }

    @Override
    public List<ActivityState> findByProcessDefinitionId(String processDefinitionId) {
        return repository.findByProcessDefinitionId(processDefinitionId).stream().map(mapper::toDomain).toList();
    }

    @Override
    public List<ActivityState> findByProcessDefinitionIdAndVersion(String processDefinitionId, Integer version) {
        return repository.findByProcessDefinitionIdAndVersion(processDefinitionId, version).stream().map(mapper::toDomain).toList();
    }

    @Override
    public ActivityState save(ActivityState activityState) {
        return repository.findByProcessDefinitionIdAndVersionAndActivityId(
                        activityState.getProcessDefinitionId(),
                        activityState.getVersion(),
                        activityState.getActivityId())
                .map(existing -> {
                    if (activityState.getId() == null) {
                        activityState.setId(existing.getId());
                    }
                    activityState.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
                    if (activityState.getCreatedAt() == null) {
                        activityState.setCreatedAt(existing.getCreatedAt());
                    }
                    return mapper.toDomain(repository.save(mapper.toDocument(activityState)));
                })
                .orElseGet(() -> {
                    activityState.setId(null);
                    activityState.setCreatedAt(OffsetDateTime.now(ZoneOffset.UTC));
                    activityState.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
                    return mapper.toDomain(repository.save(mapper.toDocument(activityState)));
                });
    }

    @Override
    public Optional<ActivityState> deleteByProcessDefinitionIdAndVersionAndActivityId(String processDefinitionId, Integer version, String activityId) {
        return repository.findByProcessDefinitionIdAndVersionAndActivityId(processDefinitionId, version, activityId)
                .map(document -> {
                    repository.delete(document);
                    return mapper.toDomain(document);
                });
    }
}
