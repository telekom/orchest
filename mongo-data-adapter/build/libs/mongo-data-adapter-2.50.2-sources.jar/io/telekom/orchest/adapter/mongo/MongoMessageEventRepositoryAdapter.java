package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.MessageEventMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoMessageEventRepository;
import io.telekom.orchest.api.core.adapters.data.model.MessageEventStore;
import io.telekom.orchest.api.core.adapters.data.repository.MessageEventRepository;
import io.telekom.orchest.api.core.model.bpmn.IntermediateEventState;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


/**
 * MongoDB implementation of the {@link MessageEventRepository}.
 * Adapts the Spring Data MongoDB repository to the domain-agnostic repository interface.
 * Manages message event subscriptions (start events and intermediate catch events).
 */
@Repository
@RequiredArgsConstructor
public class MongoMessageEventRepositoryAdapter implements MessageEventRepository {

    private final MongoMessageEventRepository repository;
    private final MessageEventMapper mapper;

    @Override
    public MessageEventStore registerEvent(MessageEventStore timedEvent) {
        return mapper.toDomain(repository.save(mapper.toDocument(timedEvent)));
    }

    @Override
    public List<MessageEventStore> findRegisteredMessageEvent(String messageName, String correlationId) {
        return repository.findAllByMessageNameAndCorrelationKeyAndState(messageName, correlationId, IntermediateEventState.REGISTERED)
                .stream().map(mapper::toDomain).toList();
    }

    @Override
    public Optional<MessageEventStore> findMessageStartEvent(String messageName) {
        return repository.findByMessageNameAndIsStartEvent(messageName, true).map(mapper::toDomain);
    }

    @Override
    public Optional<MessageEventStore> findMessageEvent(String messageName, String correlationId) {
        if(correlationId == null){
            return findMessageStartEvent(messageName);
        }
        return findRegisteredMessageEvent(messageName, correlationId).stream().findFirst();
    }

    @Override
    public Optional<MessageEventStore> findStartMessageEvent(String processDefinitionId) {
        return repository.findMessageEventStoreByProcessDefinitionIdAndIsStartEvent(processDefinitionId, true).map(mapper::toDomain);
    }

    @Override
    public void deleteByLinkedEventId(String linkedEventId) {
        repository.deleteByLinkedEventId(linkedEventId);
    }

    @Override
    public void remove(MessageEventStore messageEventStore) {
        repository.delete(mapper.toDocument(messageEventStore));
    }

    @Override
    public void deleteStartEventByDefinitionId(String definitionId) {
        repository.deleteByProcessDefinitionIdAndIsStartEvent(definitionId, true);
    }

    @Override
    public void deleteByProcessInstanceId(String processInstanceId) {
        repository.deleteByProcessInstanceId(processInstanceId);
    }
}
