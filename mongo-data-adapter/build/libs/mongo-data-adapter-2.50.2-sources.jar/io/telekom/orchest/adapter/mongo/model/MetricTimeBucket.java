package io.telekom.orchest.adapter.mongo.model;

import io.telekom.orchest.telemetry.metrics.MetricType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

/**
 * Mongo persistence shape for one minute-granularity time bucket.
 *
 * <p>{@code _id} is composed as
 * {@code <metricType>::<definitionId|_>::<version|_>::<bucketEpochMillis>} so each
 * (key, minute) tuple owns exactly one document and the upsert filter is free.
 *
 * <p>All indices for this collection (including the TTL on {@code bucketStart}) are
 * declared imperatively in {@code MongoIndicesConfiguration}.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document
public class MetricTimeBucket {

    @Id
    private String id;

    private MetricType metricType;

    private String definitionId;

    private Integer version;

    private Instant bucketStart;

    private long count;

    private Instant lastUpdatedAt;
}
