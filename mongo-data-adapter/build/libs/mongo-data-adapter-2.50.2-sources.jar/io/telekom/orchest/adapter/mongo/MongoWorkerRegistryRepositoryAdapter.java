package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.WorkerRegistryMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoWorkerRegistryRepository;
import io.telekom.orchest.api.core.adapters.data.model.WorkerRegistry;
import io.telekom.orchest.api.core.adapters.data.repository.WorkerRegistryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * MongoDB implementation of the {@link WorkerRegistryRepository}.
 * Adapts the Spring Data MongoDB repository to the domain-agnostic repository interface.
 * Manages storage of registered workers.
 */
@Repository
@RequiredArgsConstructor
public class MongoWorkerRegistryRepositoryAdapter implements WorkerRegistryRepository {

    private final MongoWorkerRegistryRepository repository;
    private final WorkerRegistryMapper mapper;


    @Override
    public List<WorkerRegistry> findAllByProcessDefinitionId(String processDefinitionId) {
        return repository.findAllByProcessDefinitionId(processDefinitionId).stream().map(mapper::toDomain).toList();
    }

    @Override
    public Optional<WorkerRegistry> findByNameSpace(String namespace) {
        return repository.findByNameSpace(namespace).map(mapper::toDomain);
    }

    @Override
    public WorkerRegistry save(WorkerRegistry workerRegistry) {
        return mapper.toDomain(repository.save(mapper.toDocument(workerRegistry)));
    }
}
