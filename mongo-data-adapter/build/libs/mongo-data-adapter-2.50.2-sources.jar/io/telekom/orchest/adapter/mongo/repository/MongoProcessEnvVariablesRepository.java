package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.ProcessEnvVariables;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MongoProcessEnvVariablesRepository extends MongoRepository<ProcessEnvVariables, String> {

    List<ProcessEnvVariables> findAllByProcessDefinitionId(String processDefinitionId);
}
