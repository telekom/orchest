package io.telekom.orchest.adapter.mongo.mapper;

import io.telekom.orchest.adapter.mongo.model.Incident;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = IncidentMapper.class)
public interface IncidentMapper {

    Incident toDocument(io.telekom.orchest.api.core.adapters.data.model.Incident domain);

    io.telekom.orchest.api.core.adapters.data.model.Incident toDomain(Incident document);
}
