package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.DecisionDefinitionMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoDecisionDefinitionRepository;
import io.telekom.orchest.api.core.adapters.data.model.DecisionDefinition;
import io.telekom.orchest.api.core.adapters.data.repository.DecisionDefinitionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * MongoDB implementation of the {@link DecisionDefinitionRepository}.
 * Adapts the Spring Data MongoDB repository to the domain-agnostic repository interface.
 * Handles storage, retrieval, and versioning of DMN decision definitions.
 */
@Component
@RequiredArgsConstructor
public class MongoDecisionDefinitionRepositoryAdapter implements DecisionDefinitionRepository {

    private final MongoDecisionDefinitionRepository repository;
    private final DecisionDefinitionMapper mapper;
    private final MongoTemplate mongoTemplate;

    @Override
    public List<DecisionDefinition> getDecisionDefinition() {
        return repository.findAllDecisions().stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public List<DecisionDefinition> getById(String definitionId) {
        Query query = getFindQuery(definitionId, null);
        List<io.telekom.orchest.adapter.mongo.model.DecisionDefinition> decisionDefinitions = mongoTemplate.find(query, io.telekom.orchest.adapter.mongo.model.DecisionDefinition.class);
        return decisionDefinitions.stream().map(mapper::toDomain).toList();
    }

    @Override
    public Optional<DecisionDefinition> getLatestById(String decisionId) {
        Query query = getFindQuery(decisionId, null).with(
                Sort.by(
                        Sort.Order.desc("version")
                )
        );
        List<io.telekom.orchest.adapter.mongo.model.DecisionDefinition> decisionDefinitions = mongoTemplate.find(query, io.telekom.orchest.adapter.mongo.model.DecisionDefinition.class);
        return decisionDefinitions.stream().map(mapper::toDomain).findFirst();
    }

    @Override
    public Optional<DecisionDefinition> getByDecisionIdAndVersion(String decisionId, Integer version) {
        Query query = getFindQuery(decisionId, version).with(
                Sort.by(
                        Sort.Order.desc("version")
                )
        );
        List<io.telekom.orchest.adapter.mongo.model.DecisionDefinition> decisionDefinitions = mongoTemplate.find(query, io.telekom.orchest.adapter.mongo.model.DecisionDefinition.class);
        return decisionDefinitions.stream().map(mapper::toDomain).findFirst();
    }

    @Override
    public Optional<DecisionDefinition> getLatestByDefinitionId(String definitionId) {
        return repository.findFirstByDefinitionIdOrderByVersionDesc(definitionId).map(mapper::toDomain);
    }

    @Override
    public Optional<DecisionDefinition> getByIdAndVersion(String definitionId, Integer version) {
        Query query = getFindQuery(definitionId, version);
        List<io.telekom.orchest.adapter.mongo.model.DecisionDefinition> decisionDefinitions = mongoTemplate.find(query, io.telekom.orchest.adapter.mongo.model.DecisionDefinition.class);
        return decisionDefinitions.stream().map(mapper::toDomain).findFirst();
    }

    @Override
    public Optional<DecisionDefinition> getByDefinitionIdAndVersion(String definitionId, Integer version) {
        return repository.findByDefinitionIdAndVersion(definitionId, version).map(mapper::toDomain);
    }

    @Override
    public DecisionDefinition save(DecisionDefinition processDefinition) {
        return mapper.toDomain(repository.save(mapper.toDocument(processDefinition)));
    }

    @Override
    public List<DecisionDefinition> findAllDefinitions(int page, int size) {
        Query query = new Query().with(PageRequest.of(page, size));
        query.fields().include("definitionId", "version", "decisionIds");
        return mongoTemplate.find(query, DecisionDefinition.class);
    }

    @Override
    public boolean deleteByDefinitionIdAndVersion(String definitionId, Integer version) {
        Long deletedCount = repository.deleteByDefinitionIdAndVersion(definitionId, version);
        return deletedCount > 0;
    }

    private Query getFindQuery(String definitionId, Integer version) {
        Query query = new Query();
        if (version != null) {
            query.addCriteria(Criteria.where("decisionIds").is(definitionId).and("version").is(version));
        } else {
            query.addCriteria(Criteria.where("decisionIds").is(definitionId));
        }
        return query;
    }

}
