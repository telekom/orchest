package io.telekom.orchest.adapter.mongo.config;

import io.telekom.orchest.adapter.mongo.model.WorkerRegistry;
import io.telekom.orchest.api.core.adapters.data.model.ActivityState;
import io.telekom.orchest.api.core.adapters.data.repository.ActivityStateRepository;
import io.telekom.orchest.api.core.request.WorkerRegistryRequest;
import io.telekom.orchest.cache.core.CacheDefinition;
import io.telekom.orchest.cache.core.CacheHooks;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class InMemoryCachingConfiguration {

//    @Bean
//    public CacheDefinition<String, ProcessDefinition, io.telekom.orchest.api.core.adapters.data.model.ProcessDefinition> processDefinitionCacheDefinition(MongoTemplate mongo, ProcessDefinitionMapper mapper) {
//        return CacheDefinition.<String, ProcessDefinition,
//                        io.telekom.orchest.api.core.adapters.data.model.ProcessDefinition>builder()
//                .name("processDefinitionCache")
//                .loader(() -> mongo.findAll(ProcessDefinition.class))
//                .transform(mapper::toDomain)
//                .keyExtractor(io.telekom.orchest.api.core.adapters.data.model.ProcessDefinition::getId)
//                .refreshInterval(Duration.ofSeconds(5))
//                .loadOnStartup(true)
//                .failSafe(true)
//                .retryAttempts(2)
//                .retryBackoff(Duration.ofSeconds(1))
//                .build();
//    }
//
//    @Bean
//    public CacheDefinition<String, DecisionDefinition, io.telekom.orchest.api.core.adapters.data.model.DecisionDefinition> decisionDefinitionCacheDefinition(MongoTemplate mongo, DecisionDefinitionMapper mapper) {
//        return CacheDefinition.<String, DecisionDefinition,
//                        io.telekom.orchest.api.core.adapters.data.model.DecisionDefinition>builder()
//                .name("decisionDefinitionCache")
//                .loader(() -> mongo.findAll(DecisionDefinition.class))
//                .transform(mapper::toDomain)
//                .keyExtractor(io.telekom.orchest.api.core.adapters.data.model.DecisionDefinition::getId)
//                .refreshInterval(Duration.ofSeconds(5))
//                .loadOnStartup(true)
//                .failSafe(true)
//                .retryAttempts(2)
//                .retryBackoff(Duration.ofSeconds(1))
//                .build();
//    }

    @Bean("commonWorkersMap")
    public Map<String, Boolean> commonWorkersMap() {
        return new ConcurrentHashMap<>();
    }

    @Bean
    public CacheDefinition<String, WorkerRegistry, WorkerRegistry> workerRegistryCacheDefinition(
            MongoTemplate mongo,
            @Qualifier("commonWorkersMap") Map<String, Boolean> commonWorkersMap) {
        return CacheDefinition.<String, WorkerRegistry, WorkerRegistry>builder()
                .name("workerRegistryCache")
                .loader(() -> mongo.findAll(WorkerRegistry.class))
                .keyExtractor(WorkerRegistry::getNameSpace)
                .refreshInterval(Duration.ofSeconds(5))
                .loadOnStartup(true)
                .failSafe(true)
                .retryAttempts(2)
                .retryBackoff(Duration.ofSeconds(1))
                .hooks(new CacheHooks<>() {
                    @Override
                    public void afterRefresh(String cacheName, Map<String, WorkerRegistry> snapshot, long durationMillis) {
                        Map<String, Boolean> newValues = new ConcurrentHashMap<>();
                        snapshot.values().forEach(workerRegistry -> {
                            if (workerRegistry == null || workerRegistry.getWorkerInfos() == null || workerRegistry.getWorkerInfos().isEmpty()) {
                                return;
                            }
                            workerRegistry.getWorkerInfos()
                                    .stream()
                                    .filter(WorkerRegistryRequest.WorkerInfo::isCommonWorker)
                                    .forEach(workerInfo -> newValues.put(workerInfo.getType(), true));
                        });
                        commonWorkersMap.clear();
                        commonWorkersMap.putAll(newValues);
                        log.debug("registered common workers count: {}", commonWorkersMap.size());
                    }
                })
                .build();
    }

    @Bean
    public CacheDefinition<String, ActivityState, ActivityState> activityStateCacheDefinition(
            ActivityStateRepository activityStateRepository) {
        return CacheDefinition.<String, ActivityState, ActivityState>builder()
                .name("activityStateCache")
                .loader(activityStateRepository::findAll)
                .keyExtractor(as -> as.getProcessDefinitionId() + "_" + as.getVersion() + "_" + as.getActivityId())
                .refreshInterval(Duration.ofSeconds(10))
                .loadOnStartup(true)
                .failSafe(true)
                .retryAttempts(2)
                .retryBackoff(Duration.ofSeconds(1))
                .build();
    }
}