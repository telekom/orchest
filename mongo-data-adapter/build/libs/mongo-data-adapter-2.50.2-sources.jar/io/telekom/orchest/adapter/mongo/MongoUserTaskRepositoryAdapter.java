package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.UserTaskInstanceMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoUserTaskRepository;
import io.telekom.orchest.api.core.adapters.data.model.UserTaskInstance;
import io.telekom.orchest.api.core.adapters.data.model.UserTaskInstance.TaskState;
import io.telekom.orchest.api.core.adapters.data.repository.UserTaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

/**
 * MongoDB implementation of the {@link UserTaskRepository}.
 * Adapts the Spring Data MongoDB repository to the domain-agnostic repository interface.
 * Manages the full lifecycle of user task instances (create, claim, complete, cancel).
 */
@Repository
@RequiredArgsConstructor
public class MongoUserTaskRepositoryAdapter implements UserTaskRepository {

    private final MongoUserTaskRepository repository;
    private final UserTaskInstanceMapper mapper;

    private static final List<String> ACTIVE_STATES = List.of(
            TaskState.CREATED.name(),
            TaskState.CLAIMED.name()
    );

    @Override
    public UserTaskInstance save(UserTaskInstance userTask) {
        io.telekom.orchest.adapter.mongo.model.UserTaskInstance saved = repository.save(mapper.toDocument(userTask));
        userTask.setId(saved.getId());
        return userTask;
    }

    @Override
    public Optional<UserTaskInstance> findByTaskId(String taskId) {
        return repository.findByTaskId(taskId).map(mapper::toDomain);
    }

    @Override
    public List<UserTaskInstance> findActiveByProcessInstanceId(String processInstanceId) {
        return repository.findByProcessInstanceIdAndStateIn(processInstanceId, ACTIVE_STATES)
                .stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public List<UserTaskInstance> findByAssignee(String userId) {
        return repository.findByAssigneeAndStateIn(userId, ACTIVE_STATES)
                .stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public List<UserTaskInstance> findAvailableForUser(String userId, List<String> userGroups) {
        List<String> groups = userGroups != null ? userGroups : List.of();
        return repository.findAvailableForUser(userId, groups)
                .stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public Optional<UserTaskInstance> findByProcessInstanceIdAndActivityId(String processInstanceId, String activityId) {
        return repository.findByProcessInstanceIdAndStateIn(processInstanceId, ACTIVE_STATES)
                .stream()
                .filter(task -> activityId.equals(task.getActivityId()))
                .findFirst()
                .map(mapper::toDomain);
    }

    @Override
    public void cancelAllByProcessInstanceId(String processInstanceId) {
        List<io.telekom.orchest.adapter.mongo.model.UserTaskInstance> activeTasks =
                repository.findByProcessInstanceIdAndStateIn(processInstanceId, ACTIVE_STATES);
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        activeTasks.forEach(task -> {
            task.setState(TaskState.CANCELLED.name());
            task.setCompletedAt(now);
            repository.save(task);
        });
    }

    @Override
    public void remove(UserTaskInstance userTask) {
        if (userTask.getId() != null) {
            repository.deleteById(userTask.getId());
        }
    }
}
