package io.telekom.orchest.adapter.mongo.model;

import io.telekom.orchest.api.core.adapters.data.model.AlertState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document
public class Alert {

    @Id
    private String id;
    private String source;
    private String alertKey;
    private String fingerprint;
    private AlertState state;
    private long count;
    private String severity;

    @Builder.Default
    private Map<String, String> metadata = new HashMap<>();

    private String subject;
    private String body;
    private Recipients recipients;
    private Long resendIntervalMs;

    private Instant createdAt;
    private Instant updatedAt;
    private Instant lastTriggeredAt;
    private Instant resolvedAt;
    private Instant acknowledgedAt;
    private String acknowledgedBy;
    private Instant silencedAt;
    private String silencedBy;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Recipients {
        @Builder.Default
        private List<String> to = new ArrayList<>();
        @Builder.Default
        private List<String> cc = new ArrayList<>();
        @Builder.Default
        private List<String> bcc = new ArrayList<>();
    }
}
