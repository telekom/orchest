package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.Connector;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Spring Data MongoDB repository for {@link Connector} documents.
 * Handles database operations for connectors.
 */
@Repository
public interface MongoConnectorRepository extends MongoRepository<Connector, String> {
    Optional<Connector> findByConnectorName(String connectorName);

}
