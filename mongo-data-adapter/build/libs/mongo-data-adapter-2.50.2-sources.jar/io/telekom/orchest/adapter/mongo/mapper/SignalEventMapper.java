package io.telekom.orchest.adapter.mongo.mapper;


import io.telekom.orchest.adapter.mongo.model.SignalEvent;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface SignalEventMapper {

    SignalEvent toDocument(io.telekom.orchest.api.core.adapters.data.model.SignalEvent domain);

    io.telekom.orchest.api.core.adapters.data.model.SignalEvent toDomain(SignalEvent document);

}
