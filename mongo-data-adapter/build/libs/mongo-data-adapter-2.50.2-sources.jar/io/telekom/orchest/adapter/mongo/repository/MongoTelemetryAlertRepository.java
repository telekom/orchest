package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.Alert;
import io.telekom.orchest.api.core.adapters.data.model.AlertState;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MongoTelemetryAlertRepository extends MongoRepository<Alert, String> {

    Optional<Alert> findByFingerprint(String fingerprint);

    List<Alert> findAllByState(AlertState state);
}
