package io.telekom.orchest.adapter.mongo.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document
public class AlertingMailerConfig {

    @Id
    private String id;
    private String processId;
    private Alert.Recipients alertingRecipient;

    private OffsetDateTime createdAt;
    private OffsetDateTime lastModifiedAt;
}
