package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.UserTaskInstance;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data MongoDB repository for {@link UserTaskInstance} documents.
 * Handles storage and retrieval of user task instances.
 */
@Repository
public interface MongoUserTaskRepository extends MongoRepository<UserTaskInstance, String> {

    Optional<UserTaskInstance> findByTaskId(String taskId);

    List<UserTaskInstance> findByProcessInstanceIdAndStateIn(String processInstanceId, List<String> states);

    List<UserTaskInstance> findByAssigneeAndStateIn(String assignee, List<String> states);

    /**
     * Finds user tasks available to a user: tasks where the user is the assignee,
     * is in candidateUsers, or one of their groups is in candidateGroups.
     * Only returns tasks in CREATED or CLAIMED state.
     */
    @Query("{ $and: [ " +
            "  { 'state': { $in: ['CREATED', 'CLAIMED'] } }, " +
            "  { $or: [ " +
            "    { 'assignee': ?0 }, " +
            "    { 'claimedBy': ?0 }, " +
            "    { 'candidateUsers': ?0 }, " +
            "    { 'candidateGroups': { $in: ?1 } }, " +
            "    { $and: [ " +
            "      { 'assignee': null }, " +
            "      { 'candidateUsers': { $size: 0 } }, " +
            "      { 'candidateGroups': { $size: 0 } } " +
            "    ] } " +
            "  ] } " +
            "] }")
    List<UserTaskInstance> findAvailableForUser(String userId, List<String> userGroups);

    List<UserTaskInstance> findByProcessInstanceIdAndState(String processInstanceId, String state);
}
