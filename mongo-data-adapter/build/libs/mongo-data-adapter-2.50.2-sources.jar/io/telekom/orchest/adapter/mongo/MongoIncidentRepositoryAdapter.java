package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.IncidentMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoIncidentRepository;
import io.telekom.orchest.api.core.adapters.data.model.Incident;
import io.telekom.orchest.api.core.adapters.data.repository.IncidentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class MongoIncidentRepositoryAdapter implements IncidentRepository {
    private final MongoIncidentRepository mongoIncidentRepository;
    private final IncidentMapper mapper;

    @Override
    public List<Incident> findByProcessInstanceId(String processInstanceId) {
        return mongoIncidentRepository.findByProcessInstanceId(processInstanceId)
                .stream().map(mapper::toDomain).toList();
    }

    @Override
    public List<Incident> findByProcessDefinitionId(String processDefinitionId) {
        return mongoIncidentRepository.findByProcessDefinitionId(processDefinitionId)
                .stream().map(mapper::toDomain).toList();
    }

    @Override
    public Incident save(Incident incident) {
        return mapper.toDomain(mongoIncidentRepository.save(mapper.toDocument(incident)));
    }
}
