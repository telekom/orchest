package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.DecisionDefinition;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data MongoDB repository for {@link DecisionDefinition} documents.
 * Provides custom query methods for finding DMN definitions by ID and version.
 */
@Repository
public interface MongoDecisionDefinitionRepository extends MongoRepository<DecisionDefinition, String> {
    List<DecisionDefinition> findAllByDefinitionId(String definitionId);
    Optional<DecisionDefinition> findFirstByDefinitionIdOrderByVersionDesc(String definitionId);
    Optional<DecisionDefinition> findByDefinitionIdAndVersion(String definitionId, Integer version);

    @Query(value = "{}", fields = "{definitionId: 1, version: 1, decisionIds:  1}")
    List<DecisionDefinition> findAllDecisions();

    @Aggregation(pipeline = {
            "{ '$group': { '_id': '$definitionId' }}",
            "{ '$project': { 'definitionId': '$_id' } }"
    })
    List<DecisionDefinition> findDistinctDecisionIds();

    Long deleteByDefinitionIdAndVersion(String definitionId, Integer version);
}
