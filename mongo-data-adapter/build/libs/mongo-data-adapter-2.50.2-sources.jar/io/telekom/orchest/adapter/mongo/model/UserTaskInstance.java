package io.telekom.orchest.adapter.mongo.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * MongoDB document for storing User Task instances.
 * Tracks the lifecycle of user tasks including assignment, claiming, and completion.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document
public class UserTaskInstance {

    @Id
    private String id;

    private String taskId;

    private String processInstanceId;

    private String processDefinitionId;

    private String activityId;

    private String taskName;

    private String state;

    private String assignee;

    @Builder.Default
    private List<String> candidateUsers = new ArrayList<>();

    @Builder.Default
    private List<String> candidateGroups = new ArrayList<>();

    private String claimedBy;

    private String dueDate;

    private String followUpDate;

    private String formKey;

    @Builder.Default
    private Map<String, Object> variables = new HashMap<>();

    @CreatedDate
    private OffsetDateTime createdAt;

    private OffsetDateTime claimedAt;

    private OffsetDateTime completedAt;
}
