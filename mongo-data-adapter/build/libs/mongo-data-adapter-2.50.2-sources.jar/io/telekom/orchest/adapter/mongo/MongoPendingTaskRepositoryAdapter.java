package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.PendingTaskMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoPendingTaskRepository;
import io.telekom.orchest.api.core.adapters.data.model.PendingTask;
import io.telekom.orchest.api.core.adapters.data.repository.PendingTaskRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.stream.Stream;

/**
 * MongoDB implementation of the {@link PendingTaskRepository}.
 * Adapts the Spring Data MongoDB repository to the domain-agnostic repository interface.
 * Manages pending tasks that are waiting for worker availability.
 */
@Repository
@RequiredArgsConstructor
public class MongoPendingTaskRepositoryAdapter implements PendingTaskRepository {

    private final MongoPendingTaskRepository repository;
    private final PendingTaskMapper mapper;

    @Override
    public Stream<PendingTask> findAllByWorkerIdIn(Collection<String> workerIds) {
        return repository.findAllByWorkerIdIn(workerIds).map(mapper::toDomain);
    }

    @Override
    public void remove(PendingTask task) {
        repository.delete(mapper.toDocument(task));
    }

    @Override
    public PendingTask save(PendingTask pendingTask) {
        return mapper.toDomain(repository.save(mapper.toDocument(pendingTask)));
    }

    @Override
    public void deleteByProcessInstanceId(String processInstanceId) {
        repository.deleteByProcessInstanceId(processInstanceId);
    }
}
