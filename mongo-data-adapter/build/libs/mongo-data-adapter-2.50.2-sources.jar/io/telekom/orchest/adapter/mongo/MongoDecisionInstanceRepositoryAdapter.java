package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.DecisionInstanceMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoDecisionInstanceRepository;
import io.telekom.orchest.api.core.adapters.data.model.DecisionInstance;
import io.telekom.orchest.api.core.adapters.data.repository.DecisionInstanceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * MongoDB implementation of the {@link DecisionInstanceRepository}.
 * Adapts the Spring Data MongoDB repository to the domain-agnostic repository interface.
 * Handles storage and retrieval of DMN decision instances.
 */
@Component
@RequiredArgsConstructor
public class MongoDecisionInstanceRepositoryAdapter implements DecisionInstanceRepository {

    private final MongoDecisionInstanceRepository decisionInstanceRepository;
    private final DecisionInstanceMapper mapper;
    private final MongoTemplate mongoTemplate;

    @Override
    public List<DecisionInstance> getDecisionInstances() {
        return decisionInstanceRepository.findAll()
                .stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public List<DecisionInstance> getDecisionInstances(List<String> fields) {
        Query query = new Query();
        if (fields != null) {
            fields.forEach(field -> query.fields().include(field));
        }
        return mongoTemplate.find(query, DecisionInstance.class);
    }

    @Override
    public Optional<DecisionInstance> getById(String decisionInstanceId) {
        return decisionInstanceRepository.findByDecisionInstanceId(decisionInstanceId).map(mapper::toDomain);
    }

    @Override
    public DecisionInstance save(DecisionInstance decisionInstance) {
        return mapper.toDomain(decisionInstanceRepository.save(mapper.toDocument(decisionInstance)));
    }

}
