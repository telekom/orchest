package io.telekom.orchest.adapter.mongo.cache;

import io.telekom.orchest.api.core.adapters.data.model.ProcessDefinition;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
public class InMemoryProcessDefinitionCache {
    private final Map<String, List<ProcessDefinition>> cache = new ConcurrentHashMap<>();
    private final Map<String, String> entityIdToDefinitionIdMap = new ConcurrentHashMap<>();

    public void init(List<ProcessDefinition> processDefinitions) {
//        log.info("Initializing process definition cache...");
//        processDefinitions.forEach(this::put);
//        log.info("Initialized process definition cache.");
    }

    public void put(ProcessDefinition value) {
        String key = value.getDefinitionId();
        List<ProcessDefinition> processDefinitions;
        if (cache.containsKey(key)) {
            processDefinitions = cache.get(key);
        } else {
            processDefinitions = new ArrayList<>();
        }
        processDefinitions.add(value);
        cache.put(key, processDefinitions);
        entityIdToDefinitionIdMap.put(value.getId(), value.getDefinitionId());
    }

    public void removeViaEntityId(String entityId) {
        cache.remove(entityIdToDefinitionIdMap.get(entityId));
        entityIdToDefinitionIdMap.remove(entityId);
    }

    public String getDefinitionIdViaEntity(String entityId) {
        return entityIdToDefinitionIdMap.get(entityId);
    }

    public ProcessDefinition get(String processDefinitionId) {
        List<ProcessDefinition> processDefinitions = cache.get(processDefinitionId);
        if (processDefinitions == null || processDefinitions.isEmpty()) {
            return null;
        }
        processDefinitions.sort(Comparator.comparing(ProcessDefinition::getVersion).reversed());
        return processDefinitions.getFirst();
    }

    public List<ProcessDefinition> getAll(String processDefinitionId) {
        return cache.get(processDefinitionId);
    }

    public ProcessDefinition getWithVersion(String processDefinitionId, Integer version) {
        List<ProcessDefinition> processDefinitions = cache.get(processDefinitionId);
        if (processDefinitions == null) {
            return null;
        }
        return processDefinitions.stream()
                .filter(processDefinition -> processDefinition.getVersion().equals(version))
                .findFirst()
                .orElse(null);
    }

    public boolean contains(String key) {
        return cache.containsKey(key);
    }


    public void removeVersion(String definitionId, Integer version) {
        List<ProcessDefinition> processDefinitions = cache.get(definitionId);
        if (processDefinitions != null) {
            processDefinitions.removeIf(pd -> pd.getVersion().equals(version));
            if (processDefinitions.isEmpty()) {
                cache.remove(definitionId);
            }
        }
    }

    public void clear() {
        cache.clear();
    }

}
