package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.SignalEventMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoSignalEventRepository;
import io.telekom.orchest.api.core.adapters.data.model.SignalEvent;
import io.telekom.orchest.api.core.adapters.data.repository.SignalEventRepository;
import io.telekom.orchest.api.core.model.bpmn.IntermediateEventState;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * MongoDB implementation of the {@link SignalEventRepository}.
 * Adapts the Spring Data MongoDB repository to the domain-agnostic repository interface.
 * Manages registration and retrieval of signal event subscriptions.
 */
@Repository
@RequiredArgsConstructor
public class MongoSignalEventRepositoryAdapter implements SignalEventRepository {

    private final MongoSignalEventRepository repository;
    private final SignalEventMapper mapper;

    @Override
    public SignalEvent registerEvent(SignalEvent signalEvent) {
        io.telekom.orchest.adapter.mongo.model.SignalEvent save = repository.save(mapper.toDocument(signalEvent));
        signalEvent.setId(save.getId());
        return signalEvent;
    }

    @Override
    public Optional<SignalEvent> findSignalStartEvent(String processDefinitionId) {
        return repository.findSignalEventByProcessDefinitionIdAndIsStartEvent(processDefinitionId, true)
                .map(mapper::toDomain);
    }

    @Override
    public List<SignalEvent> findAllRegisteredSignalsEvent(String signalName) {
        return repository.findAllBySignalNameAndState(signalName, IntermediateEventState.REGISTERED).stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public void deleteByLinkedEventId(String linkedEventId) {
        repository.deleteByLinkedEventId(linkedEventId);
    }

    @Override
    public void remove(SignalEvent timedEvent) {
        repository.deleteById(timedEvent.getId());
    }

    @Override
    public void deleteStartEventByDefinitionId(String definitionId) {
        repository.deleteSignalEventByProcessDefinitionIdAndIsStartEvent(definitionId, true);
    }

    @Override
    public void deleteByProcessInstanceId(String processInstanceId) {
        repository.deleteByProcessInstanceId(processInstanceId);
    }
}
