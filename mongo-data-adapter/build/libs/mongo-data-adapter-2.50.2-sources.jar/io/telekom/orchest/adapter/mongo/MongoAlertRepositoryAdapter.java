package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.AlertMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoTelemetryAlertRepository;
import io.telekom.orchest.api.core.adapters.data.model.Alert;
import io.telekom.orchest.api.core.adapters.data.model.AlertState;
import io.telekom.orchest.api.core.adapters.data.repository.AlertRepository;
import lombok.RequiredArgsConstructor;
import org.bson.Document;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class MongoAlertRepositoryAdapter implements AlertRepository {

    private final MongoTelemetryAlertRepository repository;
    private final AlertMapper mapper;
    private final MongoTemplate mongoTemplate;

    @Override
    public Alert save(Alert alert) {
        return mapper.toDomain(repository.save(mapper.toDocument(alert)));
    }

    @Override
    public Optional<Alert> findById(String id) {
        return repository.findById(id).map(mapper::toDomain);
    }

    @Override
    public Optional<Alert> findByFingerprint(String fingerprint) {
        return repository.findByFingerprint(fingerprint).map(mapper::toDomain);
    }

    @Override
    public List<Alert> findAll() {
        return repository.findAll().stream().map(mapper::toDomain).toList();
    }

    @Override
    public List<Alert> findByState(AlertState state) {
        return repository.findAllByState(state).stream().map(mapper::toDomain).toList();
    }

    @Override
    public AlertPage findByStates(Collection<AlertState> states, int page, int size) {
        Query query = new Query();
        query.addCriteria(Criteria.where("state").in(states));
        query.with(Sort.by(Sort.Direction.DESC, "createdAt"));
        long total = mongoTemplate.count(query, io.telekom.orchest.adapter.mongo.model.Alert.class);
        query.with(PageRequest.of(page, size));
        List<Alert> content = mongoTemplate.find(query, io.telekom.orchest.adapter.mongo.model.Alert.class)
                .stream().map(mapper::toDomain).toList();
        int totalPages = size == 0 ? 0 : (int) Math.ceil((double) total / size);
        return new AlertPage(content, total, totalPages, page, size);
    }

    @Override
    public AlertPage findAll(AlertState state, String processDefinitionId, Instant createdFrom, Instant createdTo, int page, int size, String sort) {
        Query query = new Query();
        if (state != null) {
            query.addCriteria(Criteria.where("state").is(state));
        }
        if (processDefinitionId != null) {
            query.addCriteria(Criteria.where("metadata.processDefinitionId").is(processDefinitionId));
        }
        if (createdFrom != null || createdTo != null) {
            Criteria c = Criteria.where("createdAt");
            if (createdFrom != null) c = c.gte(createdFrom);
            if (createdTo != null) c = c.lte(createdTo);
            query.addCriteria(c);
        }
        query.with(parseSort(sort));

        long total = mongoTemplate.count(query, io.telekom.orchest.adapter.mongo.model.Alert.class);
        query.with(PageRequest.of(page, size));
        List<Alert> content = mongoTemplate.find(query, io.telekom.orchest.adapter.mongo.model.Alert.class)
                .stream().map(mapper::toDomain).toList();

        int totalPages = size == 0 ? 0 : (int) Math.ceil((double) total / size);
        return new AlertPage(content, total, totalPages, page, size);
    }

    @Override
    public List<AlertStats> firingStats() {
        Aggregation agg = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("state").is(AlertState.FIRING)),
                Aggregation.group("metadata.processDefinitionId", "metadata.version")
                        .sum("count").as("totalCount"),
                Aggregation.project("totalCount")
                        .and("_id.processDefinitionId").as("processDefinitionId")
                        .and("_id.version").as("version"),
                Aggregation.sort(Sort.Direction.DESC, "totalCount")
        );
        AggregationResults<Document> results = mongoTemplate.aggregate(agg, io.telekom.orchest.adapter.mongo.model.Alert.class, Document.class);
        return results.getMappedResults().stream()
                .map(doc -> new AlertStats(
                        doc.getString("processDefinitionId"),
                        doc.getString("version"),
                        doc.get("totalCount") instanceof Number n ? n.longValue() : 0L))
                .toList();
    }

    private static final java.util.Set<String> SORTABLE_FIELDS = java.util.Set.of(
            "count", "createdAt", "updatedAt", "severity", "state");

    private static Sort parseSort(String sort) {
        if (sort == null || sort.isBlank()) {
            return Sort.by(Sort.Direction.DESC, "count");
        }
        Sort.Direction dir = sort.startsWith("+") ? Sort.Direction.ASC : Sort.Direction.DESC;
        String field = sort.startsWith("+") || sort.startsWith("-") ? sort.substring(1) : sort;
        if (!SORTABLE_FIELDS.contains(field)) {
            return Sort.by(Sort.Direction.DESC, "count");
        }
        return Sort.by(dir, field);
    }
}
