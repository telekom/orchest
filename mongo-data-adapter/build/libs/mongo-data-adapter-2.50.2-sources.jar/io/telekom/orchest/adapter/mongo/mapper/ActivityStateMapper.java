package io.telekom.orchest.adapter.mongo.mapper;

import io.telekom.orchest.adapter.mongo.model.ActivityState;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ActivityStateMapper {

    ActivityState toDocument(io.telekom.orchest.api.core.adapters.data.model.ActivityState domain);

    io.telekom.orchest.api.core.adapters.data.model.ActivityState toDomain(ActivityState document);
}
