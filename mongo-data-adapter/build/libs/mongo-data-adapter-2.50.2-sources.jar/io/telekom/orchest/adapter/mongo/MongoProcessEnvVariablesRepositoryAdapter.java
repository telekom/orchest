package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.ProcessEnvVariablesMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoProcessEnvVariablesRepository;
import io.telekom.orchest.api.core.adapters.data.model.ProcessEnvVariables;
import io.telekom.orchest.api.core.adapters.data.repository.ProcessEnvVariablesRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class MongoProcessEnvVariablesRepositoryAdapter implements ProcessEnvVariablesRepository {

    private final MongoProcessEnvVariablesRepository repository;
    private final MongoTemplate mongoTemplate;
    private final ProcessEnvVariablesMapper mapper;

    @Override
    public ProcessEnvVariables save(ProcessEnvVariables processEnvVariables) {
        return mapper.toDomain(repository.save(mapper.toDocument(processEnvVariables)));
    }

    @Override
    public List<ProcessEnvVariables> getProcessDefinitions() {
        return repository.findAll()
                .stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public List<ProcessEnvVariables> getByDefinitionIdId(String definitionId) {
        return repository.findAllByProcessDefinitionId(definitionId)
                .stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public List<ProcessEnvVariables> getAll(int page, int size) {
        PageRequest pageRequest = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return mongoTemplate.find(new Query().with(pageRequest), ProcessEnvVariables.class);
    }

    @Override
    public void remove(ProcessEnvVariables processEnvVariables) {
        repository.delete(mapper.toDocument(processEnvVariables));
    }
}
