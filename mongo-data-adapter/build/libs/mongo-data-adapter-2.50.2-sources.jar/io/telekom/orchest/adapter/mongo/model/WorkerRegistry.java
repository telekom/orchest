package io.telekom.orchest.adapter.mongo.model;

import io.telekom.orchest.api.core.request.WorkerRegistryRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.OffsetDateTime;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document
public class WorkerRegistry {

    @Id
    private String id;
    private String nameSpace;
    private String processDefinitionId;
    @LastModifiedDate
    private OffsetDateTime lastRegisteredAt;
    private Set<WorkerRegistryRequest.WorkerInfo> workerInfos;
}
