package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.cache.InMemoryProcessDefinitionCache;
import io.telekom.orchest.api.core.adapters.data.model.ProcessDefinition;
import io.telekom.orchest.adapter.mongo.mapper.ProcessDefinitionMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoProcessDefinitionRepository;
import io.telekom.orchest.api.core.adapters.data.repository.ProcessDefinitionRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 * MongoDB implementation of the {@link ProcessDefinitionRepository}.
 * Adapts the Spring Data MongoDB repository to the domain-agnostic repository interface.
 */
@Component
@RequiredArgsConstructor
public class MongoProcessDefinitionRepositoryAdapter implements ProcessDefinitionRepository {

    private final MongoProcessDefinitionRepository repository;
    private final ProcessDefinitionMapper mapper;
    private final MongoTemplate mongoTemplate;
    private final InMemoryProcessDefinitionCache inMemoryProcessDefinitionCache;

    @PostConstruct
    public void initCache() {
        inMemoryProcessDefinitionCache.clear();
        inMemoryProcessDefinitionCache.init(getProcessDefinitions());
    }

    @Override
    public List<ProcessDefinition> getProcessDefinitions() {
        return repository.findAll()
                .stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public List<ProcessDefinition> getProcessDefinitions(List<String> fields) {
        return List.of();
    }

    @Override
    public List<ProcessDefinition> getById(String definitionId) {
        // cache lookup
        List<ProcessDefinition> processDefinitions = inMemoryProcessDefinitionCache.getAll(definitionId);
        if (processDefinitions != null) {
            return processDefinitions;
        }
        // DB call
        return repository.findAllByDefinitionId(definitionId)
                .stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public List<ProcessDefinition> getById(String definitionId, List<String> fields) {
        return List.of();
    }

    @Override
    public Optional<ProcessDefinition> getLatestById(String definitionId) {
        // cache lookup
        ProcessDefinition processDefinition = inMemoryProcessDefinitionCache.get(definitionId);
        if (processDefinition != null) {
            return Optional.of(processDefinition);
        }

        return repository.findFirstByDefinitionIdOrderByVersionDesc(definitionId)
                .map(mapper::toDomain);
    }

    @Override
    public Optional<ProcessDefinition> getByIdAndVersion(String definitionId, Integer version) {
        // cache lookup
        ProcessDefinition processDefinition = inMemoryProcessDefinitionCache.getWithVersion(definitionId, version);
        if (processDefinition != null) {
            return Optional.of(processDefinition);
        }

        return repository.findByDefinitionIdAndVersion(definitionId, version)
                .map(mapper::toDomain);
    }

    @Override
    public List<ProcessDefinition> findDistinctProcessIds() {
        return  repository.findDistinctProcessIds()
                .stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public List<ProcessDefinition> findAllDefinitions(int page, int size) {
        Query query = new Query().with(PageRequest.of(page, size));
        query.fields().include("definitionId","version");
        return mongoTemplate.find(query, ProcessDefinition.class);
    }

    @Override
    public List<ProcessDefinition> findAllDefinitions(int page, int size, List<String> fields) {
        Query query = new Query().with(PageRequest.of(page, size));
        if (fields != null && !fields.isEmpty()) {
            query.fields().include(fields);
        }
        return mongoTemplate.find(query, ProcessDefinition.class);
    }

    @Override
    public ProcessDefinition save(ProcessDefinition processDefinition) throws IllegalStateException {
        return mapper.toDomain(repository.save(mapper.toDocument(processDefinition)));
    }

    @Override
    public boolean deleteByDefinitionIdAndVersion(String definitionId, Integer version) {
        Long deletedCount = repository.deleteByDefinitionIdAndVersion(definitionId, version);
        if (deletedCount > 0) {
            inMemoryProcessDefinitionCache.removeVersion(definitionId, version);
            return true;
        }
        return false;
    }

    private Query getFindQuery(String definitionId, Integer version) {
        Query query = new Query();
        if (version != null) {
            query.addCriteria(Criteria.where("decisionIds").is(definitionId).and("version").is(version));
        } else {
            query.addCriteria(Criteria.where("decisionIds").is(definitionId));
        }
        return query;
    }

}
