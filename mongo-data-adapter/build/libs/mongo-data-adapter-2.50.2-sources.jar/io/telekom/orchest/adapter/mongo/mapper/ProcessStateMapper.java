package io.telekom.orchest.adapter.mongo.mapper;

import io.telekom.orchest.adapter.mongo.model.ProcessState;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ProcessStateMapper {

    ProcessState toDocument(io.telekom.orchest.api.core.adapters.data.model.ProcessState domain);

    io.telekom.orchest.api.core.adapters.data.model.ProcessState toDomain(ProcessState document);
}
