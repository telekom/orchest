package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.PendingTask;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.stream.Stream;

/**
 * Spring Data MongoDB repository for {@link PendingTask} documents.
 * Used to store and retrieve tasks waiting for worker availability.
 */
@Repository
public interface MongoPendingTaskRepository extends MongoRepository<PendingTask, String> {

    Stream<PendingTask> findAllByWorkerIdIn(Collection<String> workerIds);

    void deleteByProcessInstanceId(String processInstanceId);
}
