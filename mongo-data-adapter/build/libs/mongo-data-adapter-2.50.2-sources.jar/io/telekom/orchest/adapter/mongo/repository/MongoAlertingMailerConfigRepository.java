package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.AlertingMailerConfig;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MongoAlertingMailerConfigRepository extends MongoRepository<AlertingMailerConfig, String> {

    Optional<AlertingMailerConfig> findByProcessId(String processId);
}
