package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.Incident;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MongoIncidentRepository extends MongoRepository<Incident, String> {

    List<Incident> findByProcessInstanceId(String processInstanceId);

    List<Incident> findByProcessDefinitionId(String processDefinitionId);
}