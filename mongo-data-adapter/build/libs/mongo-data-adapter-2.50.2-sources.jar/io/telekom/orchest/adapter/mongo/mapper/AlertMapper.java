package io.telekom.orchest.adapter.mongo.mapper;

import io.telekom.orchest.adapter.mongo.model.Alert;
import io.telekom.orchest.api.core.adapters.data.model.AlertRecipients;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AlertMapper {

    Alert toDocument(io.telekom.orchest.api.core.adapters.data.model.Alert domain);

    io.telekom.orchest.api.core.adapters.data.model.Alert toDomain(Alert document);

    Alert.Recipients toDocument(AlertRecipients domain);

    AlertRecipients toDomain(Alert.Recipients document);
}
