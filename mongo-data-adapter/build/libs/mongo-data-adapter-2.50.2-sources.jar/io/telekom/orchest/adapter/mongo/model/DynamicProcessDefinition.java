package io.telekom.orchest.adapter.mongo.model;

import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * MongoDB document representing a BPMN Process Definition.
 * Stores the structure, version, and content of a deployed process.
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Document
public class DynamicProcessDefinition extends ProcessDefinition {

    private String processInstanceId;
    private List<String> agentChats;

    /**
     * Creates a DynamicProcessDefinition from an existing ProcessDefinition with additional fields.
     */
    public DynamicProcessDefinition(ProcessDefinition pd, String processInstanceId, List<String> agentChats) {
        super(pd.getId(), pd.getDefinitionId(), pd.getVersion(), pd.getName(), pd.getNodes(),
                pd.getSequenceFlows(), pd.getDefinitionXML(), pd.getStartNodeId(), true, false, pd.getCreatedAt());
        this.processInstanceId = processInstanceId;
        this.agentChats = agentChats;
    }
}
