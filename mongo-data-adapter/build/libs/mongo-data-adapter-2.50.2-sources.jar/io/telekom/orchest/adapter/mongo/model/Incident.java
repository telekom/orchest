package io.telekom.orchest.adapter.mongo.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.domain.Persistable;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document
public class Incident implements Persistable<String> {

    @Id
    private String id;

    @Indexed
    private String processInstanceId;

    @Indexed
    private String processDefinitionId;

    private Integer version;

    private String activityId;

    private String activityName;

    private String stackTrace;

    @CreatedDate
    private OffsetDateTime createdAt;

    @Override
    public boolean isNew() {
        return id == null;
    }
}