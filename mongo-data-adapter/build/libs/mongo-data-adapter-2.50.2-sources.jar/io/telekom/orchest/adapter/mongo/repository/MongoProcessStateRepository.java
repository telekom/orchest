package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.ProcessState;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MongoProcessStateRepository extends MongoRepository<ProcessState, String> {

    Optional<ProcessState> findByProcessId(String processId);
}
