package io.telekom.orchest.adapter.mongo.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.OffsetDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document
public class UserApiToken {

    @Id
    private String id;
    private String tokenId;
    private String name;
    private String tokenHash;
    private String tokenPrefix;
    private String userId;
    private List<String> roles;
    private OffsetDateTime createdAt;
    private OffsetDateTime expiresAt;
    private OffsetDateTime lastUsedAt;
    private boolean revoked;
    private OffsetDateTime revokedAt;
}
