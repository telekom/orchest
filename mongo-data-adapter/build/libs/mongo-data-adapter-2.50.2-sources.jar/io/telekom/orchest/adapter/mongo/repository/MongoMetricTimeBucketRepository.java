package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.MetricTimeBucket;
import io.telekom.orchest.telemetry.metrics.MetricType;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.Instant;
import java.util.List;

/**
 * Spring Data Mongo handle for the {@code metric_time_buckets} collection. As with
 * {@link MongoMetricLifetimeTotalRepository}, only the read path goes through this
 * interface; writes use {@code BulkOperations}.
 */
public interface MongoMetricTimeBucketRepository extends MongoRepository<MetricTimeBucket, String> {

    List<MetricTimeBucket> findAllByMetricTypeAndBucketStartGreaterThanEqualAndBucketStartLessThanOrderByBucketStartAsc(
            MetricType metricType, Instant from, Instant to);

    List<MetricTimeBucket> findAllByMetricTypeAndDefinitionIdAndBucketStartGreaterThanEqualAndBucketStartLessThanOrderByBucketStartAsc(
            MetricType metricType, String definitionId, Instant from, Instant to);
}
