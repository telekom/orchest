package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.UserApiToken;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MongoUserApiTokenRepository extends MongoRepository<UserApiToken, String> {

    Optional<UserApiToken> findByTokenHash(String tokenHash);

    List<UserApiToken> findAllByUserIdAndRevokedFalse(String userId);

    Optional<UserApiToken> findByTokenIdAndUserId(String tokenId, String userId);

    List<UserApiToken> findAllByUserId(String userId);
}
