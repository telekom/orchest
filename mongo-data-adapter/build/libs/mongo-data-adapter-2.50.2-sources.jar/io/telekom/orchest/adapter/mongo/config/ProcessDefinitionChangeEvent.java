package io.telekom.orchest.adapter.mongo.config;

import io.telekom.orchest.api.core.adapters.data.model.ProcessDefinition;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class ProcessDefinitionChangeEvent extends ApplicationEvent {

    private final ProcessDefinition processDefinition;
    private final OperationType operationType;

    public ProcessDefinitionChangeEvent(Object source, ProcessDefinition processDefinition, OperationType operationType) {
        super(source);
        this.processDefinition = processDefinition;
        this.operationType = operationType;
    }

    public enum OperationType {
        INSERT,
        DELETE
    }
}
