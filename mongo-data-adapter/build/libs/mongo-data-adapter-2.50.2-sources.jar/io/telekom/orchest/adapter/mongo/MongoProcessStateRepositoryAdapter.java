package io.telekom.orchest.adapter.mongo;

import io.telekom.orchest.adapter.mongo.mapper.ProcessStateMapper;
import io.telekom.orchest.adapter.mongo.repository.MongoProcessStateRepository;
import io.telekom.orchest.api.core.adapters.data.model.ProcessState;
import io.telekom.orchest.api.core.adapters.data.repository.ProcessStateRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class MongoProcessStateRepositoryAdapter implements ProcessStateRepository {

    private final MongoProcessStateRepository repository;
    private final ProcessStateMapper mapper;

    @Override
    public Optional<ProcessState> findByProcessId(String processId) {
        return repository.findByProcessId(processId).map(mapper::toDomain);
    }

    @Override
    public List<ProcessState> findAll() {
        return repository.findAll().stream().map(mapper::toDomain).toList();
    }

    @Override
    public ProcessState save(ProcessState processState) {
        return repository.findByProcessId(processState.getProcessId())
                .map(existing -> {
                    if (processState.getId() == null) {
                        processState.setId(existing.getId());
                    }
                    return mapper.toDomain(repository.save(mapper.toDocument(processState)));
                })
                .orElseGet(() -> mapper.toDomain(repository.save(mapper.toDocument(processState))));
    }

    @Override
    public Optional<ProcessState> deleteByProcessId(String processId) {
        return repository.findByProcessId(processId)
                .map(document -> {
                    repository.delete(document);
                    return mapper.toDomain(document);
                });
    }
}
