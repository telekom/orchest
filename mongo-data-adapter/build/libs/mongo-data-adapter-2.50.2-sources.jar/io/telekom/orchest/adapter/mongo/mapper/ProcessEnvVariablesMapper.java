package io.telekom.orchest.adapter.mongo.mapper;

import io.telekom.orchest.adapter.mongo.model.ProcessEnvVariables;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ProcessEnvVariablesMapper {

    ProcessEnvVariables toDocument(io.telekom.orchest.api.core.adapters.data.model.ProcessEnvVariables domain);


    io.telekom.orchest.api.core.adapters.data.model.ProcessEnvVariables toDomain(ProcessEnvVariables document);
}
