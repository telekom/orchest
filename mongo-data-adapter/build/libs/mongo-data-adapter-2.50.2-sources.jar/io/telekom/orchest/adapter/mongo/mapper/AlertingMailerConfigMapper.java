package io.telekom.orchest.adapter.mongo.mapper;

import io.telekom.orchest.adapter.mongo.model.AlertingMailerConfig;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = AlertMapper.class)
public interface AlertingMailerConfigMapper {

    AlertingMailerConfig toDocument(io.telekom.orchest.api.core.adapters.data.model.AlertingMailerConfig domain);

    io.telekom.orchest.api.core.adapters.data.model.AlertingMailerConfig toDomain(AlertingMailerConfig document);
}
