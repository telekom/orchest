package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.ActivityState;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MongoActivityStateRepository extends MongoRepository<ActivityState, String> {

    List<ActivityState> findByProcessDefinitionId(String processDefinitionId);

    List<ActivityState> findByProcessDefinitionIdAndVersion(String processDefinitionId, Integer version);

    Optional<ActivityState> findByProcessDefinitionIdAndVersionAndActivityId(String processDefinitionId, Integer version, String activityId);
}
