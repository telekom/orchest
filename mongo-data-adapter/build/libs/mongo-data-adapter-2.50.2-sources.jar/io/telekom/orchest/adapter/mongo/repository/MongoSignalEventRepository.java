package io.telekom.orchest.adapter.mongo.repository;

import io.telekom.orchest.adapter.mongo.model.SignalEvent;
import io.telekom.orchest.api.core.model.bpmn.IntermediateEventState;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Spring Data MongoDB repository for {@link SignalEvent} documents.
 * Handles storage and retrieval of signal event subscriptions.
 */
@Repository
public interface MongoSignalEventRepository extends MongoRepository<SignalEvent, String> {

    List<SignalEvent> findAllBySignalNameAndState(String signalEvent, IntermediateEventState state);

    Optional<SignalEvent> findBySignalNameAndIsStartEvent(String signalName, boolean isStartEvent);

    Optional<SignalEvent> findSignalEventByProcessDefinitionIdAndIsStartEvent(String processDefinitionId, Boolean isStartEvent);

    void deleteByLinkedEventId(String linkedEventId);

    void deleteSignalEventByProcessDefinitionIdAndIsStartEvent(String processDefinitionId, Boolean isStartEvent);

    void deleteByProcessInstanceId(String processInstanceId);
}
