package io.telekom.orchest.adapter.mongo.cache;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;

import java.util.Map;

@Slf4j
@Component
@DependsOn("cacheBeanRegistrar")
@RequiredArgsConstructor
public class InMemoryWorkerRegistryCache {

    private final Map<String, Boolean> commonWorkersMap;

    public boolean isCommonWorker(String workerName) {
        return commonWorkersMap.containsKey(workerName);
    }
}
