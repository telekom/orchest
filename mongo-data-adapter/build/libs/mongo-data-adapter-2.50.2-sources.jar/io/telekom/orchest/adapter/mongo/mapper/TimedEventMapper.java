package io.telekom.orchest.adapter.mongo.mapper;


import io.telekom.orchest.adapter.mongo.model.TimedEvent;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface TimedEventMapper {

    TimedEvent toDocument(io.telekom.orchest.api.core.adapters.data.model.TimedEvent domain);

    @Mapping(source = "linkedEvent", target = "isLinkedEvent")
    io.telekom.orchest.api.core.adapters.data.model.TimedEvent toDomain(TimedEvent document);

}
