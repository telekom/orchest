package io.telekom.orchest.api.core.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompensateInstanceRequest {

    private String processInstanceId;
    private String processDefinitionId;
    private Integer version;
    private Map<String, Object> variables;
}
