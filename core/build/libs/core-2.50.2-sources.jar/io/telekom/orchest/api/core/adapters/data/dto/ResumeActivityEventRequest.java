package io.telekom.orchest.api.core.adapters.data.dto;

import io.telekom.orchest.api.core.request.Variables;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResumeActivityEventRequest {

    private String processInstanceId;
    private String activityId;
    private Variables variables;
}
