package io.telekom.orchest.api.core.response;


import io.telekom.orchest.api.core.request.Variables;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateVariableResponse {
    private String id;
    private String processInstanceId;
    private Variables variables;
}
