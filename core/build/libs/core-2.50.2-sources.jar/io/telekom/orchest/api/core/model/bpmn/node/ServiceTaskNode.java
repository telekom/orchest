package io.telekom.orchest.api.core.model.bpmn.node;

import io.telekom.orchest.api.core.model.bpmn.NodeType;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Represents a Service Task node in a BPMN process.
 * A Service Task is an automated activity that invokes an external service or worker.
 */
@Setter
@NoArgsConstructor
public class ServiceTaskNode extends ActivityNode {
    private String workerType;
    private Integer retries;

    public ServiceTaskNode(String id, String name) {
        super(id, name, NodeType.SERVICE_TASK);
    }

    public String getWorkerType() {
        if (workerType != null) return workerType;
        Object val = getProperties().get("taskType");
        return val != null ? val.toString() : null;
    }

    public int getRetries() {
        if (retries != null) return retries;
        Object val = getProperties().get("retries");
        return val != null ? Integer.parseInt(val.toString()) : 3;
    }
}
