package io.telekom.orchest.api.core.adapters.data.model;


import io.telekom.orchest.api.core.model.bpmn.IntermediateEventState;
import io.telekom.orchest.api.core.model.bpmn.node.BaseNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MessageEventStore {

    private String id;
    private String correlationKey;
    private String messageName;
    private IntermediateEventState state;
    private String processInstanceId;
    private String processDefinitionId;
    private BaseNode nodeInformation;
    @Builder.Default
    private Boolean isStartEvent = false;

    private boolean isLinkedEvent;
    private String linkedEventId; // documentId of the linked EventBasedGateway

    private OffsetDateTime createdAt;
}
