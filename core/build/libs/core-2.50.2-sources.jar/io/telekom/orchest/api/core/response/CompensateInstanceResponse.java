package io.telekom.orchest.api.core.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CompensateInstanceResponse {

    private String processInstanceId;
    private String processDefinitionId;
    private Integer version;
    private String compensatedInstanceId;
}
