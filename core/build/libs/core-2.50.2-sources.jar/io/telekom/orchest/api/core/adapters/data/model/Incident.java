package io.telekom.orchest.api.core.adapters.data.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Incident {

    private String id;
    private String processInstanceId;
    private String processDefinitionId;
    private Integer version;
    private String activityId;
    private String activityName;
    private String stackTrace;
    private OffsetDateTime createdAt;
}
