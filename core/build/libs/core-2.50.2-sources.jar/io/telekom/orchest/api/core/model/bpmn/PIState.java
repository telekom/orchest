package io.telekom.orchest.api.core.model.bpmn;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public enum PIState {
    STARTED, RUNNING, HOLD, INCIDENT, COMPLETED, TERMINATED, CANCELLED, FAILED;
}
