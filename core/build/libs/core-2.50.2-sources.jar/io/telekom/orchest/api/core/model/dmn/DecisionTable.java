package io.telekom.orchest.api.core.model.dmn;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@RequiredArgsConstructor
public class DecisionTable {
    private String id;
    private String hitPolicy; // UNIQUE, FIRST, PRIORITY, ANY, COLLECT, ORDER, RULE_ORDER, OUTPUT_ORDER
    private String aggregation; // SUM, COUNT, MIN, MAX (for COLLECT hit policy)
    private List<Input> inputs = new ArrayList<>();
    private List<Output> outputs = new ArrayList<>();
    private List<Rule> rules = new ArrayList<>();

    public void addInput(Input input) {
        this.inputs.add(input);
    }
    public void addOutput(Output output) {
        this.outputs.add(output);
    }
    public void addRule(Rule rule) {
        this.rules.add(rule);
    }
}

