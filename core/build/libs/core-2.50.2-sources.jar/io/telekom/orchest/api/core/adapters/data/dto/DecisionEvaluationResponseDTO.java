package io.telekom.orchest.api.core.adapters.data.dto;

import io.telekom.orchest.api.core.model.dmn.Rule;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DecisionEvaluationResponseDTO {

    @Builder.Default
    private List<Rule> matchedRules = new ArrayList<>();
    @Builder.Default
    private Map<String, Object> inputVariables = new HashMap<>();
    @Builder.Default
    private Map<String, Object> outputVariables = new HashMap<>();
}
