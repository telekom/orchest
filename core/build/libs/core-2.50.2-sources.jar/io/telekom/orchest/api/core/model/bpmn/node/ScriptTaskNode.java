package io.telekom.orchest.api.core.model.bpmn.node;

import io.telekom.orchest.api.core.model.bpmn.NodeType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ScriptTaskNode extends ActivityNode {
    private String scriptFormat;
    private String script;
    private String resultVariable;

    public ScriptTaskNode(String id, String name) {
        super(id, name, NodeType.SCRIPT_TASK);
    }
}
