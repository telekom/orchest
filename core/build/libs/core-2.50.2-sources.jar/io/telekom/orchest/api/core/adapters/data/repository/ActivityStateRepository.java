package io.telekom.orchest.api.core.adapters.data.repository;

import io.telekom.orchest.api.core.adapters.data.model.ActivityState;

import java.util.List;
import java.util.Optional;

public interface ActivityStateRepository {

    List<ActivityState> findAll();

    List<ActivityState> findByProcessDefinitionId(String processDefinitionId);

    List<ActivityState> findByProcessDefinitionIdAndVersion(String processDefinitionId, Integer version);

    ActivityState save(ActivityState activityState);

    Optional<ActivityState> deleteByProcessDefinitionIdAndVersionAndActivityId(String processDefinitionId, Integer version, String activityId);
}
