package io.telekom.orchest.api.core.adapters.data.model;

import io.telekom.orchest.api.core.model.dmn.DIState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DecisionInstance {

    private String decisionInstanceId;
    private String definitionId;
    private String processInstanceId;
    private int version;
    private String resourceXMLUTF8String;
    private Map<String, Object> inputVariables;
    private Map<String, Object> outputVariables;

    private String encInputVariables;
    private String encOutputVariables;

    private List<String> matchedRuleIds;
    private DIState state;

    private OffsetDateTime executedAt;
}
