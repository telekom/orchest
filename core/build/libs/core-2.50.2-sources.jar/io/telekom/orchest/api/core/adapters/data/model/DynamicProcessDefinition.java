package io.telekom.orchest.api.core.adapters.data.model;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.HashMap;
import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class DynamicProcessDefinition extends ProcessDefinition {

    private String processInstanceId;
    private List<String> agentChats;

    public static DynamicProcessDefinition fromProcessDefinition(ProcessDefinition pd) {
        return DynamicProcessDefinition.builder()
                .id(pd.getId())
                .definitionId(pd.getDefinitionId())
                .version(pd.getVersion())
                .name(pd.getName())
                .nodes(pd.getNodes() != null ? new HashMap<>(pd.getNodes()) : new HashMap<>())
                .sequenceFlows(pd.getSequenceFlows() != null ? new HashMap<>(pd.getSequenceFlows()) : new HashMap<>())
                .definitionXML(pd.getDefinitionXML())
                .startNodeId(pd.getStartNodeId())
                .createdAt(pd.getCreatedAt())
                .build();
    }

}
