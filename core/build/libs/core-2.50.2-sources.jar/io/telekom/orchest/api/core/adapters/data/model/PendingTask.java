package io.telekom.orchest.api.core.adapters.data.model;

import io.telekom.orchest.api.core.adapters.data.dto.WorkerEventRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PendingTask {

    private String id;
    private String processDefinitionId;
    private String processInstanceId;
    private String workerId;
    private WorkerEventRequest workerEventRequest;
    private OffsetDateTime createdAt;
    private OffsetDateTime completedAt;
}
