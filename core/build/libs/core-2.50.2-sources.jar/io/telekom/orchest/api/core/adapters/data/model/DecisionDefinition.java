package io.telekom.orchest.api.core.adapters.data.model;

import io.telekom.orchest.api.core.model.dmn.Decision;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DecisionDefinition {
    private String id;
    private String definitionId;
    private List<String> decisionIds;
    private Integer version;
    private String name;
    private String namespace;
    private String definitionXML;
    private Map<String, Decision> decisions = new HashMap<>();

    private OffsetDateTime createdAt;

    public void addDecision(Decision decision) {
        decisions.put(decision.getId(), decision);
    }
    public Optional<Decision> getDecision(String decisionId) {
        return Optional.ofNullable(decisions.get(decisionId));
    }
}

