package io.telekom.orchest.api.core.adapters.data.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

/**
 * Persistent telemetry alert with Grafana-style lifecycle metadata and email payload.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AlertingMailerConfig {

    private String id;
    private String processId;
    private AlertRecipients alertingRecipient;

    private OffsetDateTime createdAt;
    private OffsetDateTime lastModifiedAt;
}
