package io.telekom.orchest.api.core.model.bpmn.node;

import io.telekom.orchest.api.core.model.bpmn.NodeType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ReceiveTaskNode extends ActivityNode {
    private String messageRef;

    public ReceiveTaskNode(String id, String name) {
        super(id, name, NodeType.RECEIVE_TASK);
    }
}
