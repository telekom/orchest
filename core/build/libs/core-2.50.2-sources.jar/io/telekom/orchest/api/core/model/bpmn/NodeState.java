package io.telekom.orchest.api.core.model.bpmn;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public enum NodeState {
    TRIGGERED, REGISTERED, STARTED, PENDING, INCIDENT, FAILED, COMPLETED, CANCELLED, SKIPPED
}
