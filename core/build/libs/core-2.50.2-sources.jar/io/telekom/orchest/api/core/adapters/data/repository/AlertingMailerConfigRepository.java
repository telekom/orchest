package io.telekom.orchest.api.core.adapters.data.repository;

import io.telekom.orchest.api.core.adapters.data.model.AlertingMailerConfig;

import java.util.List;
import java.util.Optional;

public interface AlertingMailerConfigRepository {

    AlertingMailerConfig save(AlertingMailerConfig config);

    Optional<AlertingMailerConfig> findById(String id);

    Optional<AlertingMailerConfig> findByProcessId(String processId);

    List<AlertingMailerConfig> findAll();

    MailerConfigPage findAll(int page, int size);

    void deleteById(String id);

    record MailerConfigPage(List<AlertingMailerConfig> content, long totalElements, int totalPages, int page, int size) {}
}
