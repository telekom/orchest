package io.telekom.orchest.api.core.adapters.connector;


import io.telekom.orchest.api.core.adapters.data.dto.WorkerEventRequest;

public interface ConnectorExecutor {

    void execute(WorkerEventRequest workerEventRequest);

}
