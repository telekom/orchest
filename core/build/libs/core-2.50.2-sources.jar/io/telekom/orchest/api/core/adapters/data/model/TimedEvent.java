package io.telekom.orchest.api.core.adapters.data.model;


import io.telekom.orchest.api.core.adapters.data.dto.WorkerEventRequest;
import io.telekom.orchest.api.core.model.bpmn.IntermediateEventState;
import io.telekom.orchest.api.core.model.bpmn.node.BaseNode;
import io.telekom.orchest.api.core.request.StateChange;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TimedEvent {

    private String id;
    private String timedEventRegistryId;
    private IntermediateEventState state;
    private Type type;
    private String value;
    private String processDefinitionId;
    private Integer version;
    private String processInstanceId;
    private BaseNode nodeInformation;
    private WorkerEventRequest eventRequest; // For task retry event

    private List<StateChange> stateChanges;
    @Builder.Default
    private Boolean isStartEvent = false;
    @Builder.Default
    private Boolean isLinkedEvent = false;
    private String linkedEventId; // documentId of the linked EventBasedGateway
    private LocalDateTime triggerAt;

    public enum Type {
        TIMER, START_EVENT_TIMER, TASK_RETRY;
    }
}
