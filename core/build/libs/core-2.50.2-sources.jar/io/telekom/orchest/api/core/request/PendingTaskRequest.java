package io.telekom.orchest.api.core.request;

import io.telekom.orchest.api.core.adapters.data.dto.WorkerEventRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PendingTaskRequest {

    private String processDefinitionId;
    private String workerId;
    private WorkerEventRequest workerEvent;
}
