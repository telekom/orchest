package io.telekom.orchest.api.core.adapters.data.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * Persistent telemetry alert with Grafana-style lifecycle metadata and email payload.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Alert {

    private String id;
    private String source;
    private String alertKey;
    private String fingerprint;

    private AlertState state;

    @Builder.Default
    private long count = 1;

    private String severity;

    @Builder.Default
    private Map<String, String> metadata = new HashMap<>();

    private String subject;
    private String body;
    private AlertRecipients recipients;

    /** Optional per-alert resend override in milliseconds. */
    private Long resendIntervalMs;

    private Instant createdAt;
    private Instant updatedAt;
    private Instant lastTriggeredAt;
    private Instant resolvedAt;
    private Instant acknowledgedAt;
    private String acknowledgedBy;
    private Instant silencedAt;
    private String silencedBy;

    public static String fingerprintOf(String source, String alertKey) {
        return source + "::" + alertKey;
    }

    public long effectiveResendIntervalMs(long defaultResendIntervalMs) {
        if (resendIntervalMs != null && resendIntervalMs > 0) {
            return resendIntervalMs;
        }
        return defaultResendIntervalMs;
    }

    public boolean isDue(Instant now, long defaultResendIntervalMs) {
        if (state != AlertState.FIRING) {
            return false;
        }
        if (lastTriggeredAt == null) {
            return true;
        }
        long intervalMs = effectiveResendIntervalMs(defaultResendIntervalMs);
        return !lastTriggeredAt.plusMillis(intervalMs).isAfter(now);
    }
}
