package io.telekom.orchest.api.core.model.dmn;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public enum DIState {
    EXECUTED, FAILED;
}
