package io.telekom.orchest.api.core.adapters.data.repository;

import io.telekom.orchest.api.core.adapters.data.model.WorkerRegistry;

import java.util.List;
import java.util.Optional;

public interface WorkerRegistryRepository {
    List<WorkerRegistry> findAllByProcessDefinitionId(String processDefinitionId);
    Optional<WorkerRegistry> findByNameSpace(String nameSpace);
    WorkerRegistry save(WorkerRegistry workerRegistry);
}
