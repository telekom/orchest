package io.telekom.orchest.api.core.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MessageEventResponse {
    private String id;
    private String messageName;
    private String correlationKey;
}
