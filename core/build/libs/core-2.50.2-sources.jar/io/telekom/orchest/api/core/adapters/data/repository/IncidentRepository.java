package io.telekom.orchest.api.core.adapters.data.repository;

import io.telekom.orchest.api.core.adapters.data.model.Incident;

import java.util.List;

public interface IncidentRepository {
    List<Incident> findByProcessInstanceId(String processInstanceId);
    List<Incident> findByProcessDefinitionId(String processDefinitionId);
    Incident save(Incident incident);
}
