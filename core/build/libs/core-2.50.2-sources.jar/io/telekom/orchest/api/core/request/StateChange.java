package io.telekom.orchest.api.core.request;

import io.telekom.orchest.api.core.model.bpmn.NodeState;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StateChange {
    private NodeState state;
    private OffsetDateTime timestamp = OffsetDateTime.now(ZoneOffset.UTC);

    public StateChange(NodeState state){
        this.state = state;
    }
}
