package io.telekom.orchest.api.core.model.bpmn;

import io.telekom.orchest.api.core.request.StateChange;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExecutionLogEntry {
    private String nodeId;
    private String nodeName;
    private NodeType nodeType;
    private String sourceNodeId;
    @Builder.Default
    private Set<String> sequenceFlowIds = new HashSet<>();
    @Builder.Default
    private List<StateChange> stateChanges = new ArrayList<>();
    @Builder.Default
    private Map<String, Object> metaData = new HashMap<>();


    public void addStateChange(StateChange stateChange) {
        if (stateChange == null || stateChange.getState() == null) {
            return;
        }
        // Idempotent against consecutive duplicates so boundary merges + engine-side
        // terminal writes (e.g. COMPLETED from resumeActivity after the worker's history
        // was already merged in) don't produce redundant timeline entries.
        if (!stateChanges.isEmpty() && stateChanges.getLast().getState() == stateChange.getState()) {
            return;
        }
        stateChanges.add(stateChange);
    }

    public void addSequenceFlowId(String sequenceFlowId) {
        sequenceFlowIds.add(sequenceFlowId);
    }

    public NodeState getState(){
        if(stateChanges == null)
            return null;
        return stateChanges.getLast().getState();
    }
}
