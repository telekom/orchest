package io.telekom.orchest.api.core.adapters.data.repository;


import io.telekom.orchest.api.core.adapters.data.model.Alert;
import io.telekom.orchest.api.core.adapters.data.model.AlertState;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * Persistence SPI for alerts. Mongo implementation lives in {@code mongo-data-adapter}.
 */
public interface AlertRepository {

    Alert save(Alert alert);

    Optional<Alert> findById(String id);

    Optional<Alert> findByFingerprint(String fingerprint);

    List<Alert> findAll();

    List<Alert> findByState(AlertState state);

    AlertPage findByStates(Collection<AlertState> states, int page, int size);

    AlertPage findAll(AlertState state, String processDefinitionId, Instant createdFrom, Instant createdTo, int page, int size, String sort);

    List<AlertStats> firingStats();

    record AlertPage(List<Alert> content, long totalElements, int totalPages, int page, int size) {}

    record AlertStats(String processDefinitionId, String version, long totalCount) {}
}
