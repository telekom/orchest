package io.telekom.orchest.api.core.adapters.data.model;


import io.telekom.orchest.api.core.model.bpmn.IntermediateEventState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EventGatewayEvent {

    private String id;
    private String eventName;
    private String eventId;
    private IntermediateEventState state;
    private String processInstanceId;
    private String executedSequenceId;
}
