package io.telekom.orchest.api.core.adapters.data.model;

/**
 * Lifecycle states for a persistent telemetry alert (Grafana-style).
 */
public enum AlertState {
    FIRING,
    ACKNOWLEDGED,
    SILENCED,
    RESOLVED,
    DISABLED
}
