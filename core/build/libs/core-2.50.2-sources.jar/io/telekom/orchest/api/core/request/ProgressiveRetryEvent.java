package io.telekom.orchest.api.core.request;

import io.telekom.orchest.api.core.adapters.data.dto.WorkerEventRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProgressiveRetryEvent {

    private WorkerEventRequest retryWorkerEvent;
}
