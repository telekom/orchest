package io.telekom.orchest.api.core.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Variables {
    private Map<String, Object> variables;
    @Builder.Default
    private VariableAction action = VariableAction.UPDATE;

    public enum VariableAction {
        UPDATE, DELETE
    }
}
