package io.telekom.orchest.api.core.model.bpmn.node;

import io.telekom.orchest.api.core.model.bpmn.NodeType;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class SendTaskNode extends ActivityNode {
    private String messageRef;

    public SendTaskNode(String id, String name) {
        super(id, name, NodeType.SEND_TASK);
    }

    public String getMessageRef() {
        if (messageRef != null) return messageRef;
        Object val = getProperties().get("messageRef");
        return val != null ? val.toString() : null;
    }

    public void setMessageRef(String messageRef) {
        this.messageRef = messageRef;
    }
}
