package io.telekom.orchest.api.core.model.bpmn.extensions;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Connector {

    private String id;
    private String connectorName;
    private Map<String, Object> connectorData;
    private OffsetDateTime createdAt;
}
