package io.telekom.orchest.api.core.adapters.data.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class IncidentEventPayload {

    private String processDefinitionId;
    private Integer version;
    private String processInstanceId;
    private String correlationId;
    private String incidentMessage;
    private String namespace;
    private String activityId;
    private String activityName;
}
