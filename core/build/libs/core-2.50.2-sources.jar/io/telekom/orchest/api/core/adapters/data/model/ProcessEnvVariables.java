package io.telekom.orchest.api.core.adapters.data.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProcessEnvVariables {

    private String id;
    private String processDefinitionId;
    private String name;
    private String value;

    private VariableType type;

    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    public  enum VariableType {
        SECRET, PLAIN_TEXT
    }
}
