package io.telekom.orchest.api.core.adapters.data.dto;

import io.telekom.orchest.api.core.model.bpmn.NodeState;
import io.telekom.orchest.api.core.model.bpmn.node.BaseNode;
import io.telekom.orchest.api.core.request.StateChange;
import io.telekom.orchest.api.core.request.Variables;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerEventRequest {

    private String eventId;
    private String processInstanceId;
    private String processDefinitionId;
    private String activityId;
    private String activityName;
    private String type;
    private String errorCode; // Error code for ERROR type events
    private boolean isCommonWorker;

    private String parentProcessInstanceId;
    private Integer version;
    private NodeState state;
    private Variables variables;
    private BaseNode nodeInformation;
    @Builder.Default
    private List<StateChange> stateChanges = new ArrayList<>();

    private String incidentMessage;
    private BoundaryMessageEvent messageEvent;
    private ErrorEvent errorEvent;

    @Builder.Default
    private int retriesLeft = 3;
    @Builder.Default
    private int retries = 3;
    private Duration retryBackOff;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ErrorEvent {
        private String errorName;
        private String errorCode;
        private String incidentMessage;

    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BoundaryMessageEvent {
        private String messageName;
        private String correlation;
    }

}
