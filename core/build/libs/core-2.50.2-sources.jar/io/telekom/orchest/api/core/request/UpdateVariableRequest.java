package io.telekom.orchest.api.core.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateVariableRequest {
    private String processInstanceId;
    private Variables variables;
}
