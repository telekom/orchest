package io.telekom.orchest.api.core.adapters.data.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Event published by the engine when a connector service task is reached.
 * The connector service consumes this event, executes the connector implementation and
 * resumes the workflow for the referenced activity.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConnectorTaskRequest {

    private String eventId;
    private String processInstanceId;
    private String processDefinitionId;
    private String activityId;
    private String activityName;
    /** Camunda connector task-definition type, e.g. {@code io.orchest:http-json:1}. */
    private String connectorType;
    private Integer version;
}
