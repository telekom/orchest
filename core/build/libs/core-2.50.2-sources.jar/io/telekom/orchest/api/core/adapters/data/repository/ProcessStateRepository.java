package io.telekom.orchest.api.core.adapters.data.repository;

import io.telekom.orchest.api.core.adapters.data.model.ProcessState;

import java.util.List;
import java.util.Optional;

/**
 * Repository for per-process enable/disable state flags.
 */
public interface ProcessStateRepository {

    Optional<ProcessState> findByProcessId(String processId);

    List<ProcessState> findAll();

    ProcessState save(ProcessState processState);

    /**
     * Deletes the process state for the given process id, if it exists.
     *
     * @param processId The process definition id.
     * @return The deleted process state, or empty if none existed.
     */
    Optional<ProcessState> deleteByProcessId(String processId);
}
