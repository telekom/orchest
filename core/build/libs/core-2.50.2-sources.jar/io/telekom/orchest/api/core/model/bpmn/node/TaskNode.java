package io.telekom.orchest.api.core.model.bpmn.node;

import io.telekom.orchest.api.core.model.bpmn.NodeType;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class TaskNode extends BaseNode {
    public TaskNode(String id, String name) {
        super(id, name, NodeType.TASK);
    }
}
