package io.telekom.orchest.api.core.request;


import io.telekom.orchest.api.core.request.StateChange;
import io.telekom.orchest.api.core.request.Variables;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SignalEventRequest {
    private String signalId;
    private String signalName;
    private Variables variables;
    private List<StateChange> stateChanges;
}
