package io.telekom.orchest.api.core.model.bpmn.node;

import io.telekom.orchest.api.core.model.bpmn.NodeType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Represents a Call Activity node in a BPMN process.
 * Call Activities invoke another process definition as a subprocess.
 */
@Getter
@Setter
@NoArgsConstructor
public class CallActivityNode extends ActivityNode {
    private String calledProcessId;
    private Boolean propagateAllParentVariables;
    private Boolean propagateAllChildVariables;

    public CallActivityNode(String id, String name) {
        super(id, name, NodeType.CALL_ACTIVITY);
    }

    public boolean isPropagateAllParentVariables() {
        if (propagateAllParentVariables != null) return propagateAllParentVariables;
        Object val = getProperties().get("propagateAllParentVariables");
        return val instanceof Boolean b ? b : true;
    }

    public boolean isPropagateAllChildVariables() {
        if (propagateAllChildVariables != null) return propagateAllChildVariables;
        Object val = getProperties().get("propagateAllChildVariables");
        return val instanceof Boolean b ? b : true;
    }
}
