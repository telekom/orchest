package io.telekom.orchest.api.core.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerRegistryRequest {

    private String namespace;
    private Set<WorkerInfo> workers;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class WorkerInfo {
        private String type;
        private boolean isCommonWorker;
    }
}
