package io.telekom.orchest.api.core.model.dmn;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Input {
    private String id;
    private String label;
    private String name;
    private String inputExpression; // FEEL expression
    private String inputVariable; // Variable name
    private String typeRef; // Data type reference

}

