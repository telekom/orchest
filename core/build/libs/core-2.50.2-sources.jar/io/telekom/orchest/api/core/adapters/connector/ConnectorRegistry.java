package io.telekom.orchest.api.core.adapters.connector;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Data
@NoArgsConstructor
public class ConnectorRegistry {
    private final Map<String, ConnectorExecutor> connectorsExecutor = new ConcurrentHashMap<>();

    public Map<String, ConnectorExecutor> addExecutor(String name, ConnectorExecutor executor) {
        connectorsExecutor.put(name, executor);
        return connectorsExecutor;
    }
}
