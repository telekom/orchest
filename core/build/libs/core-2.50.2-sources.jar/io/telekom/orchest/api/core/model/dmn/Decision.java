package io.telekom.orchest.api.core.model.dmn;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@Data
@RequiredArgsConstructor
public class Decision {
    private final String id;
    private String name;
    private DecisionTable decisionTable;
    private String question;
    private String allowedAnswers;
    private final Map<String, Object> properties = new HashMap<>();

}

