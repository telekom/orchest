package io.telekom.orchest.api.core.adapters.data.model;

import io.telekom.orchest.api.core.request.WorkerRegistryRequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkerRegistry {

    private String id;
    private String nameSpace;
    private String processDefinitionId;
    private OffsetDateTime lastRegisteredAt;
    private Set<WorkerRegistryRequest.WorkerInfo> workerInfos;
}
