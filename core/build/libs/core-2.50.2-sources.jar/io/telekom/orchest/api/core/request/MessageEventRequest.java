package io.telekom.orchest.api.core.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MessageEventRequest {
    private String id;
    private String messageName;
    private String correlationKey;
    private Variables variables;
    private List<StateChange> stateChanges;
}
