package io.telekom.orchest.api.core.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BatchCompensateInstanceRequest {

    private List<String> processInstanceIds;
    private String processDefinitionId;
    private Integer version;
}
