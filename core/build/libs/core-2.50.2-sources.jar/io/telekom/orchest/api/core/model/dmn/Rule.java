package io.telekom.orchest.api.core.model.dmn;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
public class Rule {
    private String id;
    private List<String> inputEntries = new ArrayList<>(); // FEEL expressions for input conditions
    private List<String> outputEntries = new ArrayList<>(); // FEEL expressions for output values
    private String description;
    private int ruleNumber; // Order in the decision table

    public void addInputEntry(String inputEntry) {
        this.inputEntries.add(inputEntry);
    }

    public void addOutputEntry(String outputEntry) {
        this.outputEntries.add(outputEntry);
    }

}

