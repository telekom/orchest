package io.telekom.orchest.api.core.model.bpmn;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MultiInstanceLoopCharacteristics {
    private boolean isSequential;
    private String collection; // Expression: =items
    private String elementVariable; // Variable name: item
    private String completionCondition; // Expression
    private String outputCollection;
    private String outputElement;
}

