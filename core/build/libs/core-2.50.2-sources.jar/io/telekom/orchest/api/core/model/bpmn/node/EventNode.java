package io.telekom.orchest.api.core.model.bpmn.node;

import io.telekom.orchest.api.core.model.bpmn.EventType;
import io.telekom.orchest.api.core.model.bpmn.NodeType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Represents an Event node in a BPMN process.
 * Events can be start events, end events, intermediate catch/throw events, or boundary events.
 */
@Setter
@NoArgsConstructor
public class EventNode extends BaseNode {
    @Getter private EventType eventType;
    @Getter private String attachedToId;

    // Typed event properties (replace properties map access with compile-time safety)
    private String messageName;
    private String messageCorrelationKey;
    private String signalRef;
    private String timerDuration;
    private String timerDate;
    private String timerCycle;
    private String errorRef;
    private String errorCode;
    private String escalationRef;
    private String escalationCode;
    private String condition;
    private String linkName;
    private String zeebeCorrelationKey;
    private Boolean cancelActivity;

    public EventNode(String id, String name, NodeType type, EventType eventType) {
        super(id, name, type);
        this.eventType = eventType;
    }

    public void attachTo(String targetNodeId) {
        this.attachedToId = targetNodeId;
    }

    // Typed getters with fallback to properties map for backward compat with existing MongoDB documents.
    // Old documents store these values only in the properties map. New documents have both.

    public String getMessageName() {
        return stringProp(messageName, "messageName");
    }

    public String getMessageCorrelationKey() {
        return stringProp(messageCorrelationKey, "messageCorrelationKey");
    }

    public String getSignalRef() {
        return stringProp(signalRef, "signalRef");
    }

    public String getTimerDuration() {
        return stringProp(timerDuration, "timerDuration");
    }

    public String getTimerDate() {
        return stringProp(timerDate, "timerDate");
    }

    public String getTimerCycle() {
        return stringProp(timerCycle, "timerCycle");
    }

    public String getErrorRef() {
        return stringProp(errorRef, "errorRef");
    }

    public String getErrorCode() {
        return stringProp(errorCode, "errorCode");
    }

    public String getEscalationRef() {
        return stringProp(escalationRef, "escalationRef");
    }

    public String getEscalationCode() {
        return stringProp(escalationCode, "escalationCode");
    }

    public String getCondition() {
        return stringProp(condition, "condition");
    }

    public String getLinkName() {
        return stringProp(linkName, "linkName");
    }

    public String getZeebeCorrelationKey() {
        return stringProp(zeebeCorrelationKey, "zeebeCorrelationKey");
    }

    public boolean isCancelActivity() {
        if (cancelActivity != null) return cancelActivity;
        Object val = getProperties().get("cancelActivity");
        return val instanceof Boolean b ? b : true; // default true per BPMN spec
    }

    private String stringProp(String field, String propertyKey) {
        if (field != null) return field;
        Object val = getProperties().get(propertyKey);
        return val != null ? val.toString() : null;
    }
}
