package io.telekom.orchest.orchestrest.api.validators;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DecisionInstanceValidator {


}
