package io.telekom.orchest.orchestrest.extensions.pagevisit.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageVisitStats {
    private String url;
    private LocalDate date;
    private long uniqueUsers;
}
