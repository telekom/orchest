package io.telekom.orchest.orchestrest.extensions.pagevisit.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "pageVisits")
public class PageVisit {

    @Id
    private String id;
    private String url;
    private String userId;
    private LocalDate date;
}
