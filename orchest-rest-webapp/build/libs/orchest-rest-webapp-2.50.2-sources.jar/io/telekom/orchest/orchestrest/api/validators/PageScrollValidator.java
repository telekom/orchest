package io.telekom.orchest.orchestrest.api.validators;

import io.telekom.orchest.orchestrest.api.exception.RestExceptions;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class PageScrollValidator {

    private static final int MAX_SCROLL_WINDOW = 500;

    public static void validateScroll(int from, int toExclusive) {
        if (from < 0) {
            throw new RestExceptions("from must be >= 0", 400);
        }
        if (toExclusive <= from) {
            throw new RestExceptions("to must be greater than from", 400);
        }
        int windowSize = toExclusive - from;
        if (windowSize > MAX_SCROLL_WINDOW) {
            throw new RestExceptions("scroll window (to - from) must not exceed " + MAX_SCROLL_WINDOW, 400);
        }
    }
}
