package io.telekom.orchest.orchestrest.api.dto;

import io.telekom.orchest.api.core.model.bpmn.ExecutionLogEntry;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProcessInstanceDTO {

    private String processDefinitionId;
    private String processInstanceId;
    private String parentProcessInstanceId;
    private Map<String, Object> variables;
    private String bpmnXML;
    private Integer version;
    private String incidentMessage;
    private List<String> activeElements;
    private String state;
    private Map<String, ExecutionLogEntry> sequenceExecutions;
    private String createdAt;
    private String completedAt;
    private String lastActivityAt;

}
