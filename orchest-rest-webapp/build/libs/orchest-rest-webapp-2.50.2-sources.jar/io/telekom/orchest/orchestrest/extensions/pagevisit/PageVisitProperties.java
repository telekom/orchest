package io.telekom.orchest.orchestrest.extensions.pagevisit;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "orchest.page-visits")
public class PageVisitProperties {
    private boolean enabled = false;
}
