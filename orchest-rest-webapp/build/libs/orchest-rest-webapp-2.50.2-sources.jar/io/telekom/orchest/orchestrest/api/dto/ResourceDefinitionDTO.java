package io.telekom.orchest.orchestrest.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.OffsetDateTime;
import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ResourceDefinitionDTO {

    private String definitionId;
    private String resourceXML;
    private Integer version;
    private OffsetDateTime createdAt;

    private Map<String, Object> resourceMetadata;
}
