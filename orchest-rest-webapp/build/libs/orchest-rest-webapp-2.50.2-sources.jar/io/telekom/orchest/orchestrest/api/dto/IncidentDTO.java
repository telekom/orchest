package io.telekom.orchest.orchestrest.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class IncidentDTO {

    private String processInstanceId;
    private String processDefinitionId;
    private String incidentMessage;
    private String incidentSourceInstanceId;
    private List<String> activeElements;
    private String state;
    private Integer version;
    private String createdAt;
    private String completedAt;
}
