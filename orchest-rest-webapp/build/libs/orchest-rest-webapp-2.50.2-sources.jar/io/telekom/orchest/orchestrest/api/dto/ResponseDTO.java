package io.telekom.orchest.orchestrest.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ResponseDTO<T> {
    private Meta meta;
    private T data;


    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Meta {
        private int code;
        private String message;
    }
}
