package io.telekom.orchest.orchestrest.api.request;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
public class VariablesRequest {

    private Action action;
    private String processInstanceId;
    private Map<String, Object> variables;

    public enum Action {
        ADD, UPDATE, DELETE
    }

}
