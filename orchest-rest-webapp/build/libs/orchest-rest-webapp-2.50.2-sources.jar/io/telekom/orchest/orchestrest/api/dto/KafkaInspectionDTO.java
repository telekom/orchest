package io.telekom.orchest.orchestrest.api.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

public class KafkaInspectionDTO {

    @Data
    @Builder
    public static class WorkerInfo {
        private String processDefinitionId;
        private TopicInfo clientWorkerEvent;
        private List<String> clientConsumerGroups;
        private String clientConsumerStatus;
        private TopicInfo serverWorkerEvent;
    }

    @Data
    @Builder
    public static class TopicInfo {
        private String topic;
        private String consumerGroup;
        private boolean topicExists;
        private boolean consumerGroupExists;
    }

    @Data
    @Builder
    public static class ClusterInfo {
        private List<String> topics;
        private List<String> consumerGroups;
    }

    @Data
    @Builder
    public static class ProcessHealth {
        private String processDefinitionId;
        private ResourceStatus clientWorkerEventTopic;
        private List<String> clientConsumerGroups;
        private ResourceStatus serverWorkerEventTopic;
        private ResourceStatus serverWorkerEventConsumerGroup;
        private boolean healthy;
    }

    @Data
    @Builder
    public static class ResourceStatus {
        private String name;
        private boolean exists;
    }
}
