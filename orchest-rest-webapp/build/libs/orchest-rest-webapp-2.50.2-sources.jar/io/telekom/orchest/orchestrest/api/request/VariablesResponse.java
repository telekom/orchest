package io.telekom.orchest.orchestrest.api.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VariablesResponse {

    private Map<String, Object> variables;
}
