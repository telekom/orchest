package io.telekom.orchest.orchestrest.api.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
public class SendMessageEventRequest {

    @NotBlank
    private String messageName;

    private String correlationKey;

    private Map<String, Object> variables;
}
