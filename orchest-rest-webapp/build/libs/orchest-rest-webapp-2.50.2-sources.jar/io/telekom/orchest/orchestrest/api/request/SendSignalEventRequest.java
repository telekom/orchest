package io.telekom.orchest.orchestrest.api.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
public class SendSignalEventRequest {

    @NotBlank
    private String signalName;

    private Map<String, Object> variables;
}
