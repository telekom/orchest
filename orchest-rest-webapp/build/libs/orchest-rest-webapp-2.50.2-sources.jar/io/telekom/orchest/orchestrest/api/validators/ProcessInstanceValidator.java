package io.telekom.orchest.orchestrest.api.validators;

import io.telekom.orchest.api.core.adapters.data.model.ProcessInstance;
import io.telekom.orchest.orchestrest.api.exception.RestExceptions;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Optional;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ProcessInstanceValidator {

    public static ProcessInstance getIfPresent(Optional<ProcessInstance> processInstance, String processInstanceId) {
        if (processInstance.isEmpty()) {
            throw new RestExceptions("ProcessInstance not found with id: " + processInstanceId, 400);
        }
        return processInstance.get();
    }
}
