package io.telekom.orchest.orchestrest.extensions.ratelimit.repository;

import io.telekom.orchest.orchestrest.extensions.ratelimit.model.RateLimit;
import lombok.RequiredArgsConstructor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class RateLimitRepository {

    private final MongoTemplate mongoTemplate;

    public Optional<RateLimit> findByProcessId(String processId) {
        return Optional.ofNullable(mongoTemplate.findOne(Query.query(Criteria.where("processId").is(processId)), RateLimit.class));
    }

    public List<RateLimit> findAll() {
        return mongoTemplate.findAll(RateLimit.class);
    }

    public RateLimit save(RateLimit rateLimit) {
        return mongoTemplate.save(rateLimit);
    }
}

