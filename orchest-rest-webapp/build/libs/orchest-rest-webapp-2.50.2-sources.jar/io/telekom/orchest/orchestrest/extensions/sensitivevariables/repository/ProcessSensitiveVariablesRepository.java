package io.telekom.orchest.orchestrest.extensions.sensitivevariables.repository;

import io.telekom.orchest.orchestrest.extensions.sensitivevariables.model.ProcessSensitiveVariables;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Component
public interface ProcessSensitiveVariablesRepository extends MongoRepository<ProcessSensitiveVariables, String> {

    Optional<ProcessSensitiveVariables> findByProcessDefinitionId(String processDefinitionId);

}
