package io.telekom.orchest.orchestrest.api.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PagedRequestDTO {

    private String definitionId;
    private Integer version;
    private String searchText;
    private String state;
    private LocalDateTime from;
    private LocalDateTime to;
    private int page;
    private int size;
    private String sort;
}
