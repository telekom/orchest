package io.telekom.orchest.orchestrest.api.validators;

import io.telekom.orchest.api.core.adapters.data.model.ProcessDefinition;
import io.telekom.orchest.orchestrest.api.exception.RestExceptions;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Optional;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ProcessDefinitionValidator {

    public static ProcessDefinition isPresent(Optional<ProcessDefinition> processDefinition, String processDefinitionId) {
        if (processDefinition.isEmpty()) {
            throw new RestExceptions("ProcessDefinition not found with id: " + processDefinitionId, 400);
        }
        return processDefinition.get();
    }

    public static ProcessDefinition getIfExecutable(Optional<ProcessDefinition> processDefinition, String processDefinitionId) {
        ProcessDefinition present = isPresent(processDefinition, processDefinitionId);
        if (!present.isExecutableOrLegacy()) {
            throw new RestExceptions("ProcessDefinition '" + processDefinitionId + "' is not executable", 400);
        }
        return present;
    }

}
